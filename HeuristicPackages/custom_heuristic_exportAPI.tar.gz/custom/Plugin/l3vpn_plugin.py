# !/usr/bin/env python3
import logging
import lxml.etree as ET
import lxml.objectify as objectify
from json2xml import json2xml
from itertools import combinations
import ipaddress
import uuid


# from bs4 import BeautifulSoup


# logger = logging.getLogger("Extractor")
# handler = logging.FileHandler('./custom_plugin.log')
# formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
# handler.setFormatter(formatter)
# logger.addHandler(handler)
# logger.setLevel(logging.ERROR)

# dep_namespace:
def run(xml_object, dep_class, dep_name, dep_namespace, test_run, rule_name, rule_namespace):
    result = {}
    result_list = []
    utf8_parser = ET.XMLParser(encoding='utf-8', recover=True)
    root = ET.fromstring(xml_object.encode('utf-8'), parser=utf8_parser)
    # #### To remove the namespace if its present
    for elem in root.iter():
        if not hasattr(elem.tag, 'find'): continue  # (1)
        i = elem.tag.find('}')
        if i >= 0:
            elem.tag = elem.tag[i + 1:]
    objectify.deannotate(root, cleanup_namespaces=True)
    # ####

    try:
        if dep_class == "subservice.interface.health" and dep_name == "vpn-if-health-list" and \
                dep_namespace == "custom" and \
                rule_name == "Rule-L3VPN-NM" and rule_namespace == "custom":
            return extract_subservice_vpn_interfaces_payload(root, test_run)
        elif rule_name == "Rule-L3VPN-NM" and rule_namespace == "custom" and \
                dep_class == "subservice.ebgp.nbr.health":
            return extract_subservice_ebgp_nbr_health_payload(root, test_run)

        elif rule_name == "Rule-L3VPN-NM" and rule_namespace == "custom" and \
                dep_class == "subservice.vrf.plain.lsp.reachability":
            return extract_subservice_vrf_plain_lsp_reachability_payload(root, test_run)
        elif rule_name == "Rule-L3VPN-NM" and rule_namespace == "custom" and \
                dep_class == "subservice.dynamic.l3vpn.sr.policy":
            return extract_subservice_dynamic_l3vpn_sr_policy_payload(root, test_run)
        elif rule_name == "Rule-L3VPN-NM" and rule_namespace == "custom" and \
                dep_class == "subservice.probe.session.health":
            return extract_subservice_dynamic_probe_session_payload(root, test_run)
        else:
            return result_list
    except Exception as exception:
        return "exception in running the plugin(Iter9). Error {error}".format(error=exception)


# Payload Extraction logic for subservice.vrf.plain.lsp.reachability
def extract_subservice_vrf_plain_lsp_reachability_payload(root, test_run):
    result_list = []
    if test_run:
        result_list = ["device", "vrf", "peer-vpn-addr-list"]
        return result_list

    # for device in devices:
    #     # Each result is a dictionary that can be used to instantiate one Subservice instance
    #     result = {}
    #     result["device"] = device
    #
    #     # Fetch all IP addresses except for self one
    #     peer_ntw_list = []
    #     for ip_record in all_vpn_ip_records:
    #         if ip_record.text != self_vpn_ip:
    #             version = ipaddress.ip_interface(ip_record.text).version
    #             if version == 4:
    #                 ip_intf = ipaddress.IPv4Interface(ip_record.text)
    #             else:
    #                 ip_intf = ipaddress.IPv6Interface(ip_record.text)
    #
    #             peer_ntw_str = "%s" % (ip_intf.network)
    #             peer_ntw_list.append(peer_ntw_str)
    #
    #     result["peer-vpn-addr-list"] = peer_ntw_list
    #     result_xml = json2xml.Json2xml(result, wrapper="plugin-output", pretty=True, attr_type=False).to_xml()
    #     result_list.append(result_xml)

    all_vpn_ip_records = root.xpath(".//vpn-network-accesses/vpn-network-access/ip-connection/*/local-address")
    all_vpn_prefix_length = root.xpath(".//vpn-network-accesses/vpn-network-access/ip-connection/*/prefix-length")
    all_ip_records = []
    for ip in all_vpn_ip_records:
        all_ip_records.append(ip.text)

    for vpn_node in root.findall(".//vpn-nodes/vpn-node"):
        result = {}
        device = vpn_node.find(".//vpn-node-id")
        result["device"] = device.text
        vrf = root.find(".//vpn-service/vpn-id")
        result["vrf"] = vrf.text
        self_vpn_ip = vpn_node.find(".//vpn-network-accesses/vpn-network-access/ip-connection/*/local-address")
        # Fetch all IP addresses except for self one
        # peer_ntw_list = copy.deepcopy(all_ip_records)
        # peer_ntw_list.remove(self_vpn_ip.text)

        peer_ntw_list = []
        for ip_record in all_vpn_ip_records:
            if ip_record.text != self_vpn_ip.text:
                version = ipaddress.ip_interface(ip_record.text).version
                prefix_index = all_vpn_ip_records.index(ip_record)
                ip_plus_prefix_str = ip_record.text + "/" + all_vpn_prefix_length[prefix_index].text

                if version == 4:
                    ip_ntw_str = ipaddress.IPv4Interface(ip_plus_prefix_str)
                else:
                    ip_ntw_str = ipaddress.IPv6Interface(ip_plus_prefix_str)

                peer_ntw_str = "%s" % ip_ntw_str.network

                peer_ntw_list.append(peer_ntw_str)

        result["peer-vpn-addr-list"] = peer_ntw_list
        result_xml = json2xml.Json2xml(result, wrapper="plugin-output", pretty=True,
                                       attr_type=False).to_xml()
        result_list.append(result_xml)

    return result_list


def extract_subservice_dynamic_l3vpn_sr_policy_payload(root, test_run):
    result_list = []
    if test_run:
        result_list = ["device", "vpnServiceId", "vpnAddr"]
        return result_list

    vpn_records = root.findall(".//vpn-nodes/vpn-node/vpn-node-id")
    vpn_nodes = [vpn_record.text for vpn_record in vpn_records]

    export_route_policies = root.xpath(".//devices/device/config/vrf/vrf-list/address-family/*/unicast/export/route-policy")
    for vpn_node in vpn_nodes:
        result = {}
        import_route_policy_path = ".//devices/device[key='{vpn_node}']/config/vrf/vrf-list/address-family/*/unicast/import/route-policy".format(
            vpn_node=vpn_node)
        route_policy_record = root.findall(import_route_policy_path)
        if len(route_policy_record) != 0:
            result["device"] = vpn_node
        else:
            self_export_path = ".//devices/device[key='{vpn_node}']/config/vrf/vrf-list/address-family/*/unicast/export/route-policy".format(
                vpn_node=vpn_node)
            self_export_record = root.findall(self_export_path)
            peer_export_route_policies = []

            self_export_node = False
            if len(self_export_record) != 0:
                self_export_node = True
                for route_policy in export_route_policies:
                    peer_export_route_policies.append(route_policy.text)
            else:
                for route_policy in export_route_policies:
                    peer_export_route_policies.append(route_policy.text)

            if self_export_node:
                if len(peer_export_route_policies) > len(self_export_record):
                    result["device"] = vpn_node
                else:
                    continue
            else:
                if len(peer_export_route_policies) == 0:
                    continue
            result["device"] = vpn_node

        vpn_serviceId_path = ".//vpn-service/vpn-id"
        vpn_serviceId_record = root.find(vpn_serviceId_path)
        result["vpnServiceId"] = vpn_serviceId_record.text
        vpn_addr_path = ".//vpn-service/vpn-nodes/vpn-node[vpn-node-id='{vpn_node}']/vpn-network-accesses/vpn-network-access[1]/ip-connection/*/local-address".format(
            vpn_node=vpn_node)
        vpn_addr_record = root.find(vpn_addr_path)
        result["vpnAddr"] = vpn_addr_record.text

        result_xml = json2xml.Json2xml(result, wrapper="plugin-output", pretty=True, attr_type=False).to_xml()
        result_list.append(result_xml)

    return result_list


def extract_subservice_dynamic_probe_session_payload(root, test_run):
    subservice_limit = 0
    max_subservice_limit = 200
    accedian = 'ACCEDIAN'

    result_list = []
    vpn_node_string = "vpn-node"
    if test_run:
        result_list = ["vpnServiceId", "proxyDevice","device", "peerDevice","probeSessionId"]
        return result_list

    exist = root.find(".//probes")
    if exist is None:
        return result_list
    # ipv6_exist = root.find(".//probes/endpoint/agent-ipv6")
    # if ipv6_exist is not None:
    #     return result_list

    probe_records = root.findall('.//probes/endpoint/id')

    probe_nodes = [probe_record.text for probe_record in probe_records]
    dict_nodes_map = {}
    for probe_node in probe_nodes:
        dict_nodes_map[probe_node] = {}
        vpn_node_path = ".//probes/endpoint[id='{probe_node}']/vpn-node".format(
            probe_node=probe_node)
        vpn_node = root.find(vpn_node_path)
        dict_nodes_map[probe_node][vpn_node_string] = vpn_node.text

    def generate_uuid(id):
        ns_uuid = uuid.UUID('123e4567-e89b-12d3-a456-426614174000')
        uuid_obj = uuid.uuid5(ns_uuid, id)
        uuid_str = str(uuid_obj)
        return uuid_str

    vpn_serviceId_path = ".//vpn-service/vpn-id"
    vpn_serviceId_record = root.find(vpn_serviceId_path).text

    point_to_point_list = root.find('.//probes/point-to-point')
    mesh = root.find('.//probes/mesh')
    hub_spoke_list = root.find('.//probes/hub-and-spoke')

    if point_to_point_list is not None:
        for connection in point_to_point_list.iter('connection'):
            result = {"vpnServiceId": vpn_serviceId_record, "proxyDevice": accedian}
            source_id = ''
            destination_id = ''
            for child in connection:
                if child.tag == 'source':
                    result["device"] = dict_nodes_map[child.text][vpn_node_string]
                    source_id = child.text
                if child.tag == 'destination':
                    result["peerDevice"] = dict_nodes_map[child.text][vpn_node_string]
                    destination_id = child.text
            result["probeSessionId"] = generate_uuid(vpn_serviceId_record +'_'+source_id + '_' + destination_id)
            result_xml = json2xml.Json2xml(result, wrapper="plugin-output", pretty=True, attr_type=False).to_xml()
            result_list.append(result_xml)
            subservice_limit = subservice_limit + 1
            if subservice_limit == max_subservice_limit:
                return result_list

    if mesh is not None:
        # sorting the nodes based on the endpoint id
        sorted_nodes_map = {k: v for k, v in sorted(dict_nodes_map.items())}
        # creating unique pair of combination from the sorted key
        combinations_nodes_list = list(combinations(sorted_nodes_map.keys(), 2))
        for source, destination in combinations_nodes_list:
            source_id = source
            destination_id = destination
            result = {"vpnServiceId": vpn_serviceId_record,
                      "proxyDevice": accedian,
                      "device": dict_nodes_map[source][vpn_node_string],
                      "peerDevice": dict_nodes_map[destination][vpn_node_string],
                      "probeSessionId": generate_uuid(vpn_serviceId_record+'_'+source_id + '_' + destination_id)}
            result_xml = json2xml.Json2xml(result, wrapper="plugin-output", pretty=True, attr_type=False).to_xml()
            result_list.append(result_xml)
            subservice_limit = subservice_limit + 1
            if subservice_limit == max_subservice_limit:
                return result_list

    if hub_spoke_list is not None:
        for hub_spoke in root.iter('hub-and-spoke'):
            hub_list = []
            spoke_list = []
            for child in hub_spoke:
                if child.tag == 'hub':
                    hub_list.append(child.text)
                if child.tag == 'spoke':
                    spoke_list.append(child.text)
            for hub in sorted(hub_list):
                for spoke in sorted(spoke_list):
                    source_id = hub
                    destination_id = spoke
                    result = {"vpnServiceId": vpn_serviceId_record,
                              "proxyDevice": accedian,
                              "device": dict_nodes_map[hub][vpn_node_string],
                              "peerDevice": dict_nodes_map[spoke][vpn_node_string],
                              "probeSessionId": generate_uuid(vpn_serviceId_record+'_'+source_id + '_' + destination_id)}
                    result_xml = json2xml.Json2xml(result, wrapper="plugin-output", pretty=True, attr_type=False).to_xml()
                    result_list.append(result_xml)
                    subservice_limit = subservice_limit + 1
                    if subservice_limit == max_subservice_limit:
                        return result_list
    return result_list


# Payload Extraction logic for subservice.ebgp.nbr.health
def extract_subservice_ebgp_nbr_health_payload(root, test_run):
    result_list = []
    if test_run:
        result_list = ["device", "vrf", "bgp_nbr_type", "bgp_nbr_ipaddrs"]
        return result_list

    # for device in devices:
    #     # Each result is a dictionary that can be used to instantiate one Subservice instance
    #     result = {}
    #     result["device"] = device
    #
    #     device_vrf_path = ".//flat-L3vpn/endpoint[access-pe='{device}']/vrf/vrf-definition".format(device=device)
    #     device_vrf_records = root.findall(device_vrf_path)
    #     result["vrf"] = device_vrf_records[0].text
    #
    #     ebgp_config_path = ".//flat-L3vpn/endpoint[access-pe='{device}']/ce-pe-prot/e-bgp".format(device=device)
    #     ebgp_config_records = root.findall(ebgp_config_path)
    #     if len(ebgp_config_records) == 0:
    #         continue
    #     result["bgp_nbr_type"] = ebgp_config_records[0].text
    #
    #     bgp_nbr_ipaddrs_path = ".//flat-L3vpn/endpoint[access-pe='{device}']/ce-pe-prot/e-bgp/neighbor-ipv4".format(
    #         device=device)
    #     bgp_nbr_ipaddrs_records = root.findall(bgp_nbr_ipaddrs_path)
    #     if len(bgp_nbr_ipaddrs_records) == 0:
    #         continue
    #     bgp_nbr_ipaddrs = [bgp_ipaddr_record.text for bgp_ipaddr_record in bgp_nbr_ipaddrs_records]
    #     result["bgp_nbr_ipaddrs"] = bgp_nbr_ipaddrs
    #
    #     result_xml = json2xml.Json2xml(result, wrapper="plugin-output", pretty=True, attr_type=False).to_xml()
    #     result_list.append(result_xml)

    for vpn_node in root.findall(".//vpn-nodes/vpn-node"):
        result = {}
        device = vpn_node.find(".//vpn-node-id")
        result["device"] = device.text

        vrf = root.find(".//vpn-service/vpn-id")
        result["vrf"] = vrf.text

        ebgp_config_record = vpn_node.find(
            ".//vpn-network-accesses/vpn-network-access/routing-protocols/routing-protocol/id")

        if ebgp_config_record is None:
            continue
        result["bgp_nbr_type"] = ebgp_config_record.text

        bgp_nbr_ipaddrs_records = vpn_node.findall(
            ".//vpn-network-accesses/vpn-network-access/routing-protocols/routing"
            "-protocol/bgp/neighbor")
        if len(bgp_nbr_ipaddrs_records) == 0:
            continue
        bgp_nbr_ipaddrs = [bgp_ipaddr_record.text for bgp_ipaddr_record in bgp_nbr_ipaddrs_records]
        result["bgp_nbr_ipaddrs"] = bgp_nbr_ipaddrs

        result_xml = json2xml.Json2xml(result, wrapper="plugin-output", pretty=True, attr_type=False).to_xml()
        result_list.append(result_xml)

    return result_list


def extract_subservice_vpn_interfaces_payload(root, test_run):
    result_list = []

    if test_run:
        result_list = ["device", "ifId"]
        return result_list

    device_records = root.findall('.//vpn-service/vpn-nodes/vpn-node/vpn-node-id')
    devices = [device_record.text for device_record in device_records]

    for device in devices:
        # Each result is a dictionary that can be used to instantiate one Subservice instance
        result = {}
        result["device"] = device
        interface_path = ".//vpn-nodes/vpn-node[vpn-node-id='{device}']/vpn-network-accesses/vpn-network-access/interface-id".format(
            device=device)
        device_interface_record = root.xpath(interface_path)
        vlan_interface_path = ".//vpn-nodes/vpn-node[vpn-node-id='{device}']/vpn-network-accesses/vpn-network-access/connection/encapsulation/dot1q/cvlan-id".format(
            device=device)
        vlan_interface_record = root.xpath(vlan_interface_path)

        if len(vlan_interface_record) != 0:
            result["ifId"] = device_interface_record[0].text + "." + vlan_interface_record[0].text
        else:
            result["ifId"] = device_interface_record[0].text

        result_xml = json2xml.Json2xml(result, wrapper="plugin-output", pretty=True, attr_type=False).to_xml()
        result_list.append(result_xml)

    return result_list
