# -*- mode: python; python-indent: 4 -*-
import ncs
from cisco_tsdn_core_fp_common import (
    validate_callback,
    constants as const,
    ietf_nss_const as nss_const
)
from ietf_network_slice_service.pre_post_mod import IETFNSSValidator
from ietf_network_slice_service.pre_post_mod import IETFNSSPrePostMod
from ietf_network_slice_service.slo_sle_template import SloSleTemplateService
from ietf_network_slice_service.nano_plan.components.self import IETFNSSSelfCallback
from ietf_network_slice_service.nano_plan.components.sdp import IETFNSSSDPCallback
from ietf_network_slice_service.nano_plan.components.shared_slice import IETFNSSSharedSliceCallback
from ietf_network_slice_service.actions import (
    IETFNSSInternalPlanChangeHandler,
    IETFNSSCleanupAction,
    IETFNSSErrorRecoveryAction
)


class Main(ncs.application.Application):
    def setup(self):
        self.log.info('ietf-network-slice-service RUNNING')

        # Validation
        self.IETF_NSS_validation = validate_callback.\
            ValPointRegistrar(self.log,
                              nss_const.IETF_NSS_VALIDATION_POINT_,
                              nss_const.IETF_NSS_VALIDATION_POINT,
                              IETFNSSValidator(self.log))

        # Pre/Post Mod
        self.register_service(nss_const.IETF_NSS_SERVICEPOINT, IETFNSSPrePostMod)

        # slo-sle-template
        self.register_service(nss_const.IETF_NSS_SST_SERVICEPOINT, SloSleTemplateService)

        # self
        self.register_nano_service(nss_const.IETF_NSS_SERVICEPOINT,
                                   const.NCS_SELF,
                                   const.NCS_INIT,
                                   IETFNSSSelfCallback)

        self.register_nano_service(nss_const.IETF_NSS_SERVICEPOINT,
                                   const.NCS_SELF,
                                   const.NCS_READY,
                                   IETFNSSSelfCallback)

        # sdp
        self.register_nano_service(nss_const.IETF_NSS_SERVICEPOINT,
                                   nss_const.IETF_NSS_SDP,
                                   const.NCS_INIT,
                                   IETFNSSSDPCallback)

        self.register_nano_service(nss_const.IETF_NSS_SERVICEPOINT,
                                   nss_const.IETF_NSS_SDP,
                                   nss_const.IETF_NSS_CONFIG_APPLY,
                                   IETFNSSSDPCallback)

        self.register_nano_service(nss_const.IETF_NSS_SERVICEPOINT,
                                   nss_const.IETF_NSS_SDP,
                                   const.NCS_READY,
                                   IETFNSSSDPCallback)

        # shared-slice
        self.register_nano_service(nss_const.IETF_NSS_SERVICEPOINT,
                                   nss_const.IETF_NSS_SHARED_SLICE,
                                   const.NCS_INIT,
                                   IETFNSSSharedSliceCallback)
        self.register_nano_service(nss_const.IETF_NSS_SERVICEPOINT,
                                   nss_const.IETF_NSS_SHARED_SLICE,
                                   nss_const.IETF_NSS_CONFIG_APPLY,
                                   IETFNSSSharedSliceCallback)

        self.register_nano_service(nss_const.IETF_NSS_SERVICEPOINT,
                                   nss_const.IETF_NSS_SHARED_SLICE,
                                   const.NCS_READY,
                                   IETFNSSSharedSliceCallback)

        # actions
        self.register_action(
            nss_const.IETF_NSS_INTERNAL_PLAN_CHANGE_HANDLER, IETFNSSInternalPlanChangeHandler
        )
        self.register_action(
            nss_const.IETF_NSS_CLEANUP, IETFNSSCleanupAction
        )
        self.register_action(
            nss_const.IETF_NSS_FP_ERROR_RECOVERY, IETFNSSErrorRecoveryAction
        )

    def teardown(self):
        self.IETF_NSS_validation.cleanup()
        self.log.info('ietf-network-slice-service FINISHED')
