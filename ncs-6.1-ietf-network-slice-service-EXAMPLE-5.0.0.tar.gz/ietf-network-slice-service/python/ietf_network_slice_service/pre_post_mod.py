import ncs
import logging

from ncs.application import Service
from ncs import ITER_CONTINUE, ITER_RECURSE, ITER_STOP
from _ncs.dp import NCS_SERVICE_CREATE, NCS_SERVICE_UPDATE
from _ncs import MOP_CREATED, MOP_DELETED
from ncs.maagic import get_trans, get_node
from core_fp_common import instrumentation
from cisco_tsdn_core_fp_common import utils as TsdnUtils
from cisco_tsdn_core_fp_common.diff_iterate_wrapper import DiffIterateWrapper
from cisco_tsdn_core_fp_common.status_codes.ietf_nss_status_codes import StatusCodes
from cisco_tsdn_core_fp_common.status_codes.ietf_nss_base_exception import UserErrorException
from cisco_tsdn_core_fp_common import (
    constants as const,
    ietf_nss_const as nss_const
)
from ietf_network_slice_service import utils


class IETFNSSValidator(object):
    def __init__(self, log):
        self.log = log

    def cb_validate(self, tctx, kp, newval):
        return TsdnUtils.validate_service(self, nss_const.IETF_NSS_VALIDATION_POINT, tctx, kp)


class IETFNSSPrePostMod(Service):
    @ncs.application.Service.pre_modification
    @instrumentation.instrument_service(logging.INFO, nss_const.IETF_NSS_SERVICEPOINT)
    def cb_pre_modification(self, tctx, op, kp, root, proplist):
        proplist = dict(proplist)
        proplist["VALIDATION_ERROR"] = ""

        try:
            if (op == NCS_SERVICE_CREATE) or (op == NCS_SERVICE_UPDATE):

                status_code_cfp = root.cfp_common_status_codes__status_codes.core_function_pack
                if op == NCS_SERVICE_CREATE and not status_code_cfp.exists("IETF-NSS"):
                    raise UserErrorException(
                        self.log, StatusCodes.STATUS_CODE_NOT_LOADED
                    ).set_context(
                        "Status Code", "Missing IETF NSS status code mapping"
                    ).add_state(
                        "Keypath", str(kp)
                    ).finish()

                th = get_trans(root)

                service = get_node(th, kp)
                node_dict = dict()

                service_tag_service = str(utils.get_service_tag_service_config(service))
                orig_service_tag_service = proplist.get("SERVICE_TAG_SERVICE")

                if orig_service_tag_service is not None \
                        and service_tag_service != orig_service_tag_service:
                    raise UserErrorException(
                        self.log, StatusCodes.VALUE_UPDATE_NOT_SUPPORTED
                    ).set_context(
                        "Invalid update",
                        "'service-tag-service' cannot be updated on active service"
                    ).add_state(
                        "Keypath", str(kp)
                    ).add_state(
                        "original service-tag-service", orig_service_tag_service
                    ).add_state(
                        "updated service-tag-service", service_tag_service
                    ).finish()
                else:
                    proplist["SERVICE_TAG_SERVICE"] = str(service_tag_service)

                connectivity_type = utils.get_connection_group(service).connectivity_type
                parent_rr_route_policy = utils.get_global_settings(root).parent_rr_route_policy

                if connectivity_type == nss_const.IETF_NSS_POINT_TO_POINT:
                    if parent_rr_route_policy is None:
                        raise UserErrorException(
                            self.log, StatusCodes.MISSING_INPUT
                        ).set_context(
                            "Missing input",
                            "'parent-rr-route-policy' under 'global-settings'"
                            " must be configured for 'point-to-point' slices"
                        ).add_state(
                            "Keypath", str(kp)
                        ).finish()

                    mep_id_pool_name = \
                        root.network_slice_services.cfp_configurations.mep_id_pool_name
                    service_assurance = utils.get_slo_sle_template(root, service).service_assurance

                    if mep_id_pool_name not in root.resource_pools.id_pool \
                            and service_assurance.ethernet_service_oam:
                        raise UserErrorException(self.log, StatusCodes.MISSING_INPUT) \
                            .set_context(
                                "Missing input",
                                "Resource pool for 'mep-id-pool-name' must be configured for"
                                " 'point-to-point' slices using ethernet-service-oam") \
                            .finish()

                for sdp in service.sdps.sdp:
                    sdp_role = utils.get_sdp_role(sdp)
                    rd = sdp.rd

                    if sdp.node_id in node_dict:
                        (orig_sdp_role, orig_rd) = node_dict[sdp.node_id]
                        if sdp_role != orig_sdp_role:
                            raise UserErrorException(
                                self.log, StatusCodes.VALUE_NOT_SUPPORTED
                            ).set_context(
                                "Invalid value",
                                "'connection-group-sdp-role' must be the same for "
                                "ALL sdps using the same 'node-id'"
                            ).add_state(
                                "Keypath", str(kp)
                            ).finish()
                        if rd != orig_rd:
                            raise UserErrorException(
                                self.log, StatusCodes.VALUE_NOT_SUPPORTED
                            ).set_context(
                                "Invalid value",
                                "'rd' must be the for"
                                " ALL sdps using the same 'node-id'"
                            ).add_state(
                                "Keypath", str(kp)
                            ).finish()
                    else:
                        node_dict[sdp.node_id] = (sdp_role, rd)

        except Exception as e:
            self.log.exception(e)
            proplist["VALIDATION_ERROR"] = str(e)

        return list(proplist.items())

    @ncs.application.Service.post_modification
    @instrumentation.instrument_service(logging.INFO, nss_const.IETF_NSS_SERVICEPOINT)
    def cb_post_modification(self, tctx, op, kp, root, proplist):
        proplist_dict = dict(proplist)
        if proplist_dict.get("VALIDATION_ERROR") != "":
            return proplist

        if op == NCS_SERVICE_CREATE or op == NCS_SERVICE_UPDATE:
            th = get_trans(root)
            service = get_node(th, kp)
            service_tag_service = utils.get_service_tag_service_config(service)
            slo_sle_template = utils.get_slo_sle_template(root, service)

            service_tag_service = utils.get_service_tag_service_config(service)
            ietf_nss_plan = utils.get_ietf_nss_plan(root, service.service_id)
            ietf_nss_plan_status = utils.get_ietf_nss_plan_status(root, service.service_id)

            # The following plan.status oper-data is needed for cleanup/recovery actions;
            # therefore, they are set here in the post-mod, so the persist on service deletion
            del ietf_nss_plan_status.service_tag_service
            ietf_nss_plan_status.service_tag_service.create(service_tag_service)

            ietf_nss_plan_status.forwarding_plane_policy = slo_sle_template.forwarding_plane_policy

            (internal_sr_te_odn_name, _, _, _) = \
                utils.get_internal_sr_te_odn_details(
                    self.log,
                    tctx,
                    root,
                    utils.get_slo_sle_template(root, service),
                    service,
                    read_only_alloc=True
            )
            ietf_nss_plan_status.internal.sr_te_odn_name = internal_sr_te_odn_name

            if slo_sle_template.service_assurance.performance_measurement:
                ietf_nss_plan_status.internal.pm_svc_profile_name = \
                    slo_sle_template.service_assurance.performance_measurement.sr_te.pm_svc_profile

            for sdp in service.sdps.sdp:
                sdp_comp_key = (nss_const.IETF_NSS_SDP, sdp.sdp_id)
                sdp_comp = ietf_nss_plan.component[sdp_comp_key]

                sdp_comp.node = sdp.node_id

                del sdp_comp.attachment_circuit

                for attachment_circuit in sdp.attachment_circuits.attachment_circuit:
                    sdp_comp.attachment_circuit.create(attachment_circuit.ac_id)

            # New Shared slices must be backtracked for both CQ and non-CQ
            # They'll be pushed forward when shared slice is re-deployed
            # We don't want to differentiate between CQ and non-CQ for shared slice,
            # since we don't want to go through the shared slice service to see if any
            # devices are CQ enabled if CQ is not enabled globally
            for shared_slice_id in self.nss_shared_slice_diff_iterate(th, service):
                shared_slice_comp = utils.get_plan_component(
                    ietf_nss_plan,
                    nss_const.IETF_NSS_SHARED_SLICE,
                    shared_slice_id
                )
                shared_slice_comp.state[const.NCS_READY].status = const.STATUS_NOT_REACHED

                self_comp = utils.get_plan_component(ietf_nss_plan, const.NCS_SELF, const.SELF)
                self_comp.state[const.NCS_READY].status = const.STATUS_NOT_REACHED

            if op == NCS_SERVICE_UPDATE:
                nm_service_kp = \
                    utils.get_internal_nm_service_kp(service.service_id, service_tag_service)

                # 'update_sdps' currently holds SDP updates which may or may NOT modify the NM
                (nss_self_modified, updated_sdps) = self.nss_diff_iterate(th, service)
                (nm_self_modified, nm_vpn_nodes_modified) = self.nm_diff_iterate(th, nm_service_kp)

                global_cq_enabled = TsdnUtils.is_cq_enabled_generic(self, root, th)
                device_cq_details = TsdnUtils.is_cq_enabled(
                    self,
                    root,
                    nm_vpn_nodes_modified,
                    th,
                    utils.is_lsa_setup()
                )

                sdps_kp = f"{service._path}/sdps"

                for (device, cq_enabled) in device_cq_details:
                    (_, sdp_id_set) = \
                        utils.xpath_eval(th, sdps_kp, f"sdp[node-id='{device}']/sdp-id")

                    if cq_enabled:
                        # If any device is 'cq_enabled = True', we can expect a re-deploy for the
                        # NSS service from NM service as such we can safely set NSS
                        # self/status = 'not-reached'
                        global_cq_enabled = True

                        for sdp_id in sdp_id_set:
                            sdp_comp = utils.get_plan_component(
                                ietf_nss_plan,
                                nss_const.IETF_NSS_SDP,
                                sdp_id
                            )
                            sdp_comp.state[const.NCS_READY].status = const.STATUS_NOT_REACHED

                            # Remove SDPs which have modified the NM service
                            if sdp_id in updated_sdps:
                                updated_sdps.remove(sdp_id)
                    else:
                        for sdp_id in sdp_id_set:
                            utils.update_state_timestamp(
                                self,
                                ietf_nss_plan,
                                nss_const.IETF_NSS_SDP,
                                sdp_id
                            )

                            # Remove SDPs which have modified the NM service
                            if sdp_id in updated_sdps:
                                updated_sdps.remove(sdp_id)

                # 'updated_sdps' should only contain updated SDPs which have not updated internal NM
                # service as such we can just update the timestamps
                for sdp_id in updated_sdps:
                    utils.update_state_timestamp(
                        self,
                        ietf_nss_plan,
                        nss_const.IETF_NSS_SDP,
                        sdp_id
                    )

                # Backtrack self/ready state if NM service was modified; otherwise, we
                # just update the timestamp. Cases where NM is not modified is if 'description'
                # is updated for example, as such timestamp update is enough since we don't expect
                # a re-deploy from internal NM service to forward the plan
                if global_cq_enabled and nm_self_modified:
                    self_comp = utils.get_plan_component(ietf_nss_plan, const.NCS_SELF, const.SELF)
                    self_comp.state[const.NCS_READY].status = const.STATUS_NOT_REACHED
                elif nss_self_modified:
                    utils.update_state_timestamp(
                        self,
                        ietf_nss_plan,
                        const.NCS_SELF,
                        const.SELF
                    )

    @staticmethod
    def nss_diff_iterate(th, service) -> DiffIterateWrapper:
        # len(keypath) == 3: /network-slice-services/slice-service{L3-Dedicated}
        def diter_service(self, keypath, op, oldv, newv):
            if len(keypath) <= 3:
                return ITER_RECURSE

            if str(keypath[-4]) != "private":
                self.nss_self_modified = True
                return ITER_STOP

            return ITER_CONTINUE

        # len(keypath) == 6: /network-slice-services/slice-service{L3-Dedicated}/sdps/sdp{0}
        def diter_sdp(self, keypath, op, oldv, newv):
            if len(keypath) < 6:
                return ITER_RECURSE

            if op != MOP_CREATED and op != MOP_DELETED:
                self.updated_sdps.add(str(keypath[-6][0]))

            return ITER_CONTINUE

        # len(keypath) == 6:
        #   /network-slice-services/slice-service{L3-Dedicated}/shared/slice{Shared}
        def diter_shared_slice(self, keypath, op, oldv, newv):
            if len(keypath) < 6:
                return ITER_RECURSE

            if op == MOP_CREATED:
                self.added_shared_slices.add(str(keypath[-6][0]))

            return ITER_CONTINUE

        diff_iter = DiffIterateWrapper(
            diter_service,
            nss_self_modified=False,
            updated_sdps=set(),
            added_shared_slices=set()
        )

        th.keypath_diff_iterate(diff_iter, 0, service._path)

        diff_iter.diter = diter_sdp
        th.keypath_diff_iterate(diff_iter, 0, f"{service._path}/sdps/sdp")

        return (diff_iter.nss_self_modified, diff_iter.updated_sdps)

    @staticmethod
    def nss_shared_slice_diff_iterate(th, service) -> DiffIterateWrapper:
        # len(keypath) == 6:
        #   /network-slice-services/slice-service{L3-Dedicated}/shared/slice{Shared}
        def diter_shared_slice(self, keypath, op, oldv, newv):
            if len(keypath) < 6:
                return ITER_RECURSE

            if op == MOP_CREATED:
                self.added_shared_slices.add(str(keypath[-6][0]))

            return ITER_CONTINUE

        diff_iter = DiffIterateWrapper(diter_shared_slice, added_shared_slices=set())
        th.keypath_diff_iterate(diff_iter, 0, f"{service._path}/shared/slice")

        return diff_iter.added_shared_slices

    @staticmethod
    def nm_diff_iterate(th, nm_service_kp) -> DiffIterateWrapper:
        # len(keypath) == 4: /l2vpn-ntw/vpn-services/vpn-service{0-65008740}
        # or
        # len(keypath) == 4: /l3vpn-ntw/vpn-services/vpn-service{0-65008740}
        def diter_nm_service(self, keypath, op, oldv, newv):
            if len(keypath) <= 4:
                return ITER_RECURSE

            node = str(keypath[-5])

            if node == "service-assurance":
                self.nm_self_modified = True
            elif node != "private" and node != "vpn-nodes":
                self.nm_self_modified = True

                # context = /lXvpn-ntw/vpn-services/vpn-service{0-65008740}/vpn-nodes
                context = f"{keypath[-4:]}/vpn-nodes"
                eval_path = "vpn-node/vpn-node-id"

                (_, self.nm_vpn_nodes_modified) = utils.xpath_eval(self.trans, context, eval_path)
                return ITER_STOP

            return ITER_CONTINUE

        # len(keypath) == 7:
        #    /lXvpn-ntw/vpn-services/vpn-service{0-65008740}/vpn-nodes/vpn-node{$VPN_NODE_ID}
        def diter_nm_vpn_nodes(self, keypath, op, oldv, newv):
            if len(keypath) < 7:
                return ITER_RECURSE

            vpn_node_id = str(keypath[-7][0])

            if not (op == MOP_CREATED or op == MOP_DELETED):
                self.nm_self_modified = True
                self.nm_vpn_nodes_modified.add(vpn_node_id)
            elif vpn_node_id in self.nm_vpn_nodes_modified:
                self.nm_vpn_nodes_modified.remove(vpn_node_id)

            return ITER_CONTINUE

        diff_iter = DiffIterateWrapper(
            diter_nm_service,
            trans=th,
            nm_self_modified=False,
            nm_vpn_nodes_modified=set()
        )
        th.keypath_diff_iterate(diff_iter, 0, nm_service_kp)

        diff_iter.diter = diter_nm_vpn_nodes
        th.keypath_diff_iterate(diff_iter, 0, f"{nm_service_kp}/vpn-nodes/vpn-node")

        return (diff_iter.nm_self_modified, diff_iter.nm_vpn_nodes_modified)
