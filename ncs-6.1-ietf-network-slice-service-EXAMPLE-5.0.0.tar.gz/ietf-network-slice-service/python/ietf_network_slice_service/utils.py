import cisco_tsdn_core_fp_common.utils as TsdnUtils

from _ncs import xpath_pp_kpath
from ncs.maapi import single_read_trans
from ncs.maagic import get_root, get_trans, get_node
from ncs.template import Template, Variables
from ncs import RUNNING
from cisco_tsdn_core_fp_common import (
    constants as const,
    ietf_L2vpn_nm_const as l2nm_const,
    ietf_l3vpn_nm_const as l3nm_const,
    ietf_nss_const as nss_const
)
from cisco_tsdn_core_fp_common.status_codes.ietf_nss_status_codes import StatusCodes
from cisco_tsdn_core_fp_common.status_codes.ietf_nss_base_exception import get_status_code_class
from cisco_tsdn_core_fp_common.status_codes.ietf_nss_base_exception \
    import ResourceAllocationException
import resource_manager.id_allocator as id_allocator


def str2hkeypathref(trans, path):
    trans.cd(path)
    return trans.getcwd_kpath()


def str2xpath(trans, path):
    hkeypathref = str2hkeypathref(trans, path)
    return xpath_pp_kpath(hkeypathref)


def hkeypathref2xpath(hkeypathref):
    return xpath_pp_kpath(hkeypathref)


def xpath_eval(trans, context, eval_path):
    kps = set()
    values = set()

    def _evaluator(kp, v):
        if v is not None:
            kps.add(kp)
            values.add(str(v))

    trans.xpath_eval(eval_path, _evaluator, None, context)

    return (kps, values)


def get_internal_route_policy_name(slo_sle_template, service_id=None, evi_id=None):
    if evi_id is None:
        if slo_sle_template.forwarding_plane_policy is None:
            return

        if slo_sle_template.custom:
            if service_id is None:
                return

            return (f"NSS-{slo_sle_template.id}-{slo_sle_template.forwarding_plane_policy}"
                    f"-{service_id}-internal")
        else:
            return f"NSS-{slo_sle_template.id}-{slo_sle_template.forwarding_plane_policy}-internal"
    # The following case is only for L2 P2P
    else:
        return f"NSS-{service_id}-evi-{evi_id}-internal"


def get_sdp_internal_nm_comp_name(service, node_id, sdp_id, ac_id):
    connectivity_type = get_connection_group(service).connectivity_type

    if connectivity_type == nss_const.IETF_NSS_POINT_TO_POINT:
        return node_id
    else:
        return f"{node_id}_{sdp_id}-{ac_id}"


def get_sdp_internal_nm_comp_type(service_tag_service):
    if service_tag_service == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L2:
        return l2nm_const.L2NM_VPN_NODE_COMP_TYPE
    elif service_tag_service == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L3:
        return l3nm_const.L3NM_VPN_NODE_COMP_TYPE
    else:
        raise_invalid_service_type("get_sdp_internal_nm_comp_type()", service_tag_service)


def get_internal_vpn_id(service_id):
    return f"NSS-{service_id}-internal"


def get_internal_nm_vpn_network_access_id(sdp_id, ac_id):
    return f"{sdp_id}-{ac_id}"


def get_internal_nm_plan(root, service_id, service_tag_service):
    nm_vpn_id = get_internal_vpn_id(service_id)

    if service_tag_service == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L2:
        vpn_service_plan = root.l2vpn_ntw__l2vpn_ntw.vpn_services.vpn_service_plan
    elif service_tag_service == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L3:
        vpn_service_plan = root.l3nm__l3vpn_ntw.vpn_services.vpn_service_plan
    else:
        raise_invalid_service_type("get_internal_nm_plan()", service_tag_service)

    if nm_vpn_id in vpn_service_plan:
        return vpn_service_plan[nm_vpn_id].plan


def get_internal_nm_service_kp(service_id, service_tag_service):
    nm_vpn_id = get_internal_vpn_id(service_id)
    if service_tag_service == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L2:
        return l2nm_const.get_l2nm_service_kp(nm_vpn_id)
    elif service_tag_service == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L3:
        return l3nm_const.get_l3nm_service_kp(nm_vpn_id)
    else:
        raise_invalid_service_type("get_internal_nm_service_kp()", service_tag_service)


def get_internal_nm_service(root, service_id, service_tag_service):
    nm_service_kp = get_internal_nm_service_kp(service_id, service_tag_service)
    th = get_trans(root)

    if th.exists(nm_service_kp):
        return get_node(root, nm_service_kp)


def get_internal_sr_te_odn_name(slo_sle_template, slice_service):
    if slo_sle_template.forwarding_plane_policy_type == nss_const.AS_IS:
        return slo_sle_template.forwarding_plane_policy
    elif slo_sle_template.custom and slice_service is not None:
        return f"NSS-{slice_service.service_id}-{slo_sle_template.forwarding_plane_policy}-internal"
    elif slo_sle_template.forwarding_plane_policy_type == nss_const.AS_BLUEPRINT:
        return f"NSS-{slo_sle_template.id}-{slo_sle_template.forwarding_plane_policy}-internal"


def get_sr_te_odn_plan(root, odn_name):
    if odn_name is None:
        return

    sr_te_odn_plan = \
        root.cisco_sr_te_cfp__sr_te.cisco_sr_te_cfp_sr_odn__odn.odn_template_plan

    if odn_name in sr_te_odn_plan:
        return sr_te_odn_plan[odn_name].plan


def get_sr_te_odn_service(root, odn_name):
    if odn_name is None:
        return None

    sr_te_odn = \
        root.cisco_sr_te_cfp__sr_te.cisco_sr_te_cfp_sr_odn__odn.odn_template

    if odn_name in sr_te_odn:
        return sr_te_odn[odn_name]


def get_internal_sr_te_odn_details(log, tctx, root, slo_sle_template,
                                   slice_service=None, read_only_alloc=False):
    color = None
    color_per_slo_sle_template = False
    color_per_slice = False

    if slo_sle_template.forwarding_plane_policy is None:
        return ('', color, color_per_slo_sle_template, color_per_slice)

    internal_sr_te_odn_name = get_internal_sr_te_odn_name(slo_sle_template, slice_service)

    color_pool_name = root.ietf_nss__network_slice_services.cfp_configurations.color_pool_name

    # forwarding_policy_type = 'as-is' => uses pre-defined SR ODN color (return None)
    # forwarding_policy_type = 'as-blueprint' => allocate color per slo-sle-template
    # custom => allocate color per slice
    if slo_sle_template.forwarding_plane_policy_type == nss_const.AS_IS:
        color = get_sr_te_odn_service(root, internal_sr_te_odn_name).color

        return (internal_sr_te_odn_name, color, color_per_slo_sle_template, color_per_slice)

    elif slo_sle_template.custom:
        if slice_service is None:
            log.debug("get_color(): 'slice_service' is 'None'. Ignoring call.")
            return (internal_sr_te_odn_name, color, color_per_slo_sle_template, color_per_slice)

        color_per_slice = True

        service = slice_service
        allocation_name = f"{slice_service.service_id}-color"
        service_xpath = get_ietf_nss_service_xp(slice_service.service_id)

    elif slo_sle_template.forwarding_plane_policy_type == nss_const.AS_BLUEPRINT:
        color_per_slo_sle_template = True

        service = slo_sle_template
        allocation_name = f"{slo_sle_template.id}-color"
        service_xpath = get_ietf_nss_slo_sle_template_xp(slo_sle_template.id)

    if read_only_alloc is False:
        color = request_id_allocation(
            root,
            service,
            service_xpath,
            tctx.username,
            color_pool_name,
            allocation_name,
            log
        )
    else:
        color = read_id_allocation(
            root,
            service_xpath,
            tctx.username,
            color_pool_name,
            allocation_name,
            log
        )

    if color is None:
        internal_sr_te_odn_name = None

    return (internal_sr_te_odn_name, color, color_per_slo_sle_template, color_per_slice)


def create_dedicated_sr_te_odn(slo_sle_template, internal_sr_te_odn_name,
                               color, override_bandwidth=None):

    if internal_sr_te_odn_name is not None and color is not None:
        template = Template(slo_sle_template)
        variables = Variables()

        variables.add("INTERNAL_SR_TE_ODN_NAME", internal_sr_te_odn_name)
        variables.add("COLOR", color)

        if override_bandwidth is None:
            override_bandwidth = ''

        variables.add("OVERRIDE_BANDWIDTH", override_bandwidth)

        template.apply("ietf-nss-dedicated-sr-te-odn", variables)


def get_ietf_nss_slo_sle_template_xp(id):
    return (f"{nss_const.IETF_NSS_SST_SERVICE_PATH}[id='{id}']")


def get_ietf_nss_service_xp(service_id):
    return (f"{nss_const.IETF_NSS_SERVICE_PATH}[service-id='{service_id}']")


def get_ietf_nss_service_kp(service_id):
    return (f"{nss_const.IETF_NSS_SERVICE_PATH}{{{service_id}}}")


def get_ietf_nss_plan_kp(service_id):
    return (f"{nss_const.IETF_NSS_PLAN_PATH}{{{service_id}}}")


def get_ietf_nss_plan(root, service_id):
    ietf_nss_plan = root.ietf_nss__network_slice_services.slice_service_plan

    if service_id in ietf_nss_plan:
        return ietf_nss_plan[service_id].plan


def get_ietf_nss_plan_status(root, service_id):
    ietf_nss_plan = get_ietf_nss_plan(root, service_id)
    if ietf_nss_plan is not None:
        return ietf_nss_plan.status


def get_ietf_nss_service(root, service_id):
    ietf_nss_plan = root.ietf_nss__network_slice_services.slice_service

    if service_id in ietf_nss_plan:
        return ietf_nss_plan[service_id]


def get_ietf_nss_zombie_kp(service_id):
    zombie_service_path = get_ietf_nss_service_xp(service_id)
    return f'{const.ZOMBIE_PATH}{{"{zombie_service_path}"}}'


def is_lsa_setup():
    with single_read_trans("", "system", db=RUNNING) as th:
        try:
            root = get_root(th)
            # If this path exists, it is not LSA
            non_lsa_path = root.cisco_flat_L3vpn_fp_internal__flat_L3vpn
            if non_lsa_path:
                return False
        except Exception:
            return True


def get_slo_sle_template(root, service):
    slo_sle_template_id = service.slo_sle_template
    slo_sle_template = root.ietf_nss__network_slice_services \
        .slo_sle_templates.slo_sle_template[slo_sle_template_id]

    return slo_sle_template


def get_plan_component(plan, comp_type, comp_name):
    comp_key = (comp_type, comp_name)

    if comp_key in plan.component:
        return plan.component[comp_key]


def get_component_state(component, state_name):
    if component is None:
        return

    if state_name in component.state:
        return component.state[state_name]


def update_state_timestamp(self, plan, comp_type, comp_name, state_name=const.NCS_READY):
    component = get_plan_component(plan, comp_type, comp_name)
    if component is not None:
        state_ready =  \
            get_component_state(
                component,
                state_name
            )

        TsdnUtils.update_state_when_timestamp(self, comp_name, state_ready, "due to no CQ")
    else:
        self.log.debug(
            "Unable to update "
            f"{plan._path}/component[type='{comp_type}'][name='{comp_name}']/"
            f"state[name='{state_name}']/when as it no longer exists."
        )


def get_connection_group(service):
    # There should only be a single connection group
    connection_group = iter(service.connection_groups.connection_group).next()
    return connection_group


def get_global_settings(root):
    return root.ietf_nss__network_slice_services.global_settings


def get_sdp_role(sdp):
    # There should only by a single match-criterion
    match_criterion = \
        iter(sdp.service_match_criteria.match_criterion).next()

    return match_criterion.connection_group_sdp_role


def get_service_tag_service_config(service):
    for service_tag in service.service_tags.tag_type[nss_const.IETF_NSS_SERVICE_TAG_TYPE].value:
        return service_tag


def get_service_tag_service_oper(plan):
    for service_tag in plan.status.service_tag_service:
        return service_tag


def get_forwarding_plane_policy_oper(plan):
    return plan.status.forwarding_plane_policy


def get_internal_sr_te_odn_name_oper(plan):
    internal_sr_te_odn_name = plan.status.internal.sr_te_odn_name

    if internal_sr_te_odn_name == "":
        return None

    return internal_sr_te_odn_name


def get_evi_id_oper(plan):
    return plan.status.evi_allocation_data.evi_id


def get_evi_source_oper(plan):
    return plan.status.evi_allocation_data.evi_source


def get_evi_target_oper(plan):
    return plan.status.evi_allocation_data.evi_target


def get_sman_id_oper(plan):
    return plan.status.sman_id_allocation_data.sman_id


def save_status_code(error_msg, plan, component, log, device_name):
    # populate plan with status code details
    if "out of sync" in error_msg:
        status_code = StatusCodes[StatusCodes.DEVICE_OUT_OF_SYNC.name]
    elif "connection refused" in error_msg:
        status_code = StatusCodes[StatusCodes.CONNECTION_FAILURE.name]
    else:
        status_code = StatusCodes[StatusCodes.CONFIG_FAILURE.name]

    status_class = get_status_code_class(status_code)
    e = status_class(log, status_code, error_msg)
    e = e.set_context(e.statusCode.reason, error_msg).finish()
    e.save_to_plan(plan, component, device_name)


def raise_invalid_service_type(func_name, service_tag_service):
    raise_invalid_input(
        func_name,
        "Unsupported Service Type",
        service_tag_service
    )


def raise_invalid_connectivity_type(func_name, connectivity_type):
    raise_invalid_input(
        func_name,
        "Unsupported Connectivity Type",
        connectivity_type
    )


def raise_invalid_input(func_name, message, input):
    raise Exception(f"{func_name} - {message} : '{input}'")


def is_y_1731_enabled(root, service):
    connectivity_type = get_connection_group(service).connectivity_type
    service_assurance = get_slo_sle_template(root, service).service_assurance

    if connectivity_type == nss_const.IETF_NSS_POINT_TO_POINT \
            and service_assurance.ethernet_service_oam:
        return True

    return False


def var_or_default(var, default=''):
    if var is None:
        return default
    else:
        return var


def request_id_allocation(root, service, service_xpath, username, pool_name, allocation_name, log,
                          state=None):
    try:
        id_allocator.id_request(
            service,
            service_xpath,
            username,
            pool_name,
            allocation_name,
            False,
            alloc_sync=True,
            root=root
        )
    except Exception as e:
        raise ResourceAllocationException(log, StatusCodes.ALLOCATION_REQUEST_FAILED, str(e)) \
            .set_context("Resource Allocation Error",
                         f"({allocation_name}) allocation template failed to apply") \
            .add_state("Service", service_xpath) \
            .add_state("Pool Name", pool_name) \
            .add_state("Alloc Name", allocation_name) \
            .finish()

    return read_id_allocation(root, service_xpath, username, pool_name, allocation_name, log, state)


def read_id_allocation(root, service_xpath, username, pool_name, allocation_name, log, state=None):
    try:
        id = id_allocator.id_read(username, root, pool_name, allocation_name)

        # Allocated ID may result in the following which we need to raise an exception for
        #   id = com.tailf.pkg.idpool.exceptions.PoolExhaustedException: \
        #               ID pool mep-id-pool_Dryrun exhausted
        try:
            int(id)
        except ValueError:
            raise Exception(id)
        else:
            return id

    except Exception as e:
        if state is not None:
            state.status = const.STATUS_FAILED

        log.error(f"Allocation {allocation_name} failed, Error: {str(e)}")
        raise ResourceAllocationException(log, StatusCodes.ALLOCATION_FAILED) \
            .set_context("Resource Allocation Failed", allocation_name) \
            .add_state("Service", service_xpath).finish()


def get_pm_plan(root, pm_svc_profile):
    if pm_svc_profile is None:
        return

    if pm_svc_profile in root.cisco_pm_fp__pm.pm_plan:
        return root.cisco_pm_fp__pm.pm_plan[pm_svc_profile].plan


def get_pm_svc_profile_name_oper(plan):
    pm_svc_profile_name = plan.status.internal.pm_svc_profile_name

    if pm_svc_profile_name == "":
        return None

    return pm_svc_profile_name
