import _ncs

from ncs import RUNNING, OPERATIONAL
from ncs.dp import Action
from ncs.maapi import single_read_trans, CommitParams
from ncs.maagic import get_node, get_root

from core_fp_common import cleanup_utils as CleanupUtils

from cisco_tsdn_core_fp_common import utils as TsdnUtils
from cisco_tsdn_core_fp_common import ietf_nss_const as nss_const
from cisco_tsdn_core_fp_common import sr_te_odn_const as odn_const
from cisco_tsdn_core_fp_common import pm_const
from cisco_tsdn_core_fp_common import constants as const
from cisco_tsdn_core_fp_common.status_codes.ietf_nss_status_codes import StatusCodes
from cisco_tsdn_core_fp_common.status_codes.ietf_nss_base_exception import \
    CustomActionException

from . import utils


class IETFNSSInternalPlanChangeHandler(Action):
    """
    Action handler for NM plan change
    """
    @Action.action
    def cb_action(self, uinfo, name, kp, input, output):
        _ncs.dp.action_set_timeout(uinfo, TsdnUtils.get_action_timeout(self, uinfo.username))
        self.log.info(f"Internal plan kicker changed for: {input.kicker_id} "
                      f"{input.path} {input.tid}")

        with single_read_trans(uinfo.username, "system", db=RUNNING) as th:
            nm_vpn_id = str(utils.str2hkeypathref(th, input.path)[-4][0])

            if not (nm_vpn_id[:4] == "NSS-" and nm_vpn_id[-9:] == "-internal"):
                self.log.info(f"IETF-NSS service {nm_vpn_id} not created by IETF-NSS")
                return

            # splice out 'IETF-NSS-' and '-internal'
            ietf_nss_service_id = nm_vpn_id[4:-9]

            # # If cleanup is in progress, do not take any action
            nss_service_kp = utils.get_ietf_nss_service_kp(ietf_nss_service_id)
            if TsdnUtils.check_service_cleanup_flag(self.log, nss_service_kp, uinfo.username):
                return

            ietf_nss_zombie_kp = utils.get_ietf_nss_zombie_kp(ietf_nss_service_id)
            ietf_nss_plan = utils.get_ietf_nss_plan(get_root(th), ietf_nss_service_id)

            if th.exists(ietf_nss_zombie_kp):
                for dedicated_slice in ietf_nss_plan.status.dedicated_slice:
                    dedicated_slice_zombie_kp = \
                        utils.get_ietf_nss_zombie_kp(dedicated_slice.service_id)

                    if th.exists(dedicated_slice_zombie_kp):
                        get_node(th, dedicated_slice_zombie_kp).reactive_re_deploy()

                        self.log.info(
                            "IETF NSS Zombie Service re-deploy done for: "
                            + f"{dedicated_slice.service_id}"
                        )

                get_node(th, ietf_nss_zombie_kp).reactive_re_deploy()

                self.log.info(
                    f"IETF NSS Zombie Service re-deploy done for: {ietf_nss_service_id}"
                )
            elif ietf_nss_plan is not None:
                # We want to synchronously update shared slice before re-deploying dedicated
                # slices; otherwise, NSO will merge the re-deploys causing dedicated slices
                # to re-deploy before the shared slice and then plan for dedicated slices shared
                # components will be stuck as 'not-reached'
                sync = len(ietf_nss_plan.status.dedicated_slice) > 0
                self._try_reactive_re_deploy(th, ietf_nss_plan, ietf_nss_service_id, sync)

                for dedicated_slice in ietf_nss_plan.status.dedicated_slice:
                    ietf_nss_dedicated_plan = \
                        utils.get_ietf_nss_plan(get_root(th), dedicated_slice.service_id)

                    shared_comp_key = (nss_const.IETF_NSS_SHARED_SLICE, ietf_nss_service_id)
                    shared_slice_state = \
                        ietf_nss_dedicated_plan.component[shared_comp_key].state[const.NCS_READY]

                    if shared_slice_state.status != const.STATUS_REACHED:
                        self._try_reactive_re_deploy(
                            th,
                            ietf_nss_dedicated_plan,
                            dedicated_slice.service_id
                        )

    def _try_reactive_re_deploy(self, th, ietf_nss_plan, ietf_nss_service_id, sync=False):
        if ietf_nss_plan is not None:
            ietf_nss_service_kp = utils.get_ietf_nss_service_kp(ietf_nss_service_id)

            if len(ietf_nss_plan.component) > 0 and th.exists(ietf_nss_service_kp):
                ietf_nss_service = get_node(th, ietf_nss_service_kp)

                if sync:
                    reactive_re_deploy_input = ietf_nss_service.reactive_re_deploy.get_input()
                    reactive_re_deploy_input.sync.create()
                    ietf_nss_service.reactive_re_deploy(reactive_re_deploy_input)
                else:
                    ietf_nss_service.reactive_re_deploy()

                self.log.info(
                    f"IETF NSS Service re-deploy done for: {ietf_nss_service_id}"
                )


class IETFNSSCleanupAction(Action):
    """
    Action handler for IETF NSS services cleanup
    """
    @Action.action
    def cb_action(self, uinfo, name, kp, input, output):
        _ncs.dp.action_set_timeout(uinfo, TsdnUtils.get_action_timeout(self, uinfo.username))
        self.log.info(f"Cleanup Action for IETF NSS service={input.service} ")

        service_id = input.service
        no_networking = input.no_networking
        sdp_id_list = input.sdp if len(input.sdp) > 0 else None

        nm_vpn_id = utils.get_internal_vpn_id(service_id)
        plan_kp = utils.get_ietf_nss_plan_kp(service_id)
        service_xp = utils.get_ietf_nss_service_xp(service_id)
        service_kp = utils.get_ietf_nss_service_kp(service_id)

        cleanup_log = []
        force_back_track_comp = []

        commit_params = CommitParams()
        if no_networking:
            commit_params.no_networking()

        TsdnUtils.set_service_cleanup_flag(self, service_kp, uinfo.username)

        try:
            with single_read_trans(uinfo.username, "system", db=OPERATIONAL) as th:

                root = get_root(th)
                ietf_nss_plan = get_node(th, plan_kp).plan
                internal_sr_te_odn_name = utils.get_internal_sr_te_odn_name_oper(ietf_nss_plan)
                pm_svc_profile_name = utils.get_pm_svc_profile_name_oper(ietf_nss_plan)

                cleanup_log.append(f"Cleaning up IETF NSS service: {service_id} \n")

                service_tag_service = utils.get_service_tag_service_oper(ietf_nss_plan)

                nodes = set()
                cleanup_plan_paths = list()
                cleanup_entire_service = False

                if sdp_id_list is not None:
                    for sdp_id in sdp_id_list:
                        sdp_comp = ietf_nss_plan.component[(nss_const.IETF_NSS_SDP, sdp_id)]

                        force_back_track_comp.append(
                            (
                                sdp_comp.force_back_track,
                                service_xp
                            )
                        )

                        for ac_id in sdp_comp.attachment_circuit:
                            nodes.add(
                                (
                                    sdp_comp.name,
                                    sdp_comp.node,
                                    ac_id
                                )
                            )

                        sdp_kp = f"{service_kp}/sdps/sdp{{{sdp_id}}}"
                        CleanupUtils.delete_service(self, sdp_kp, cleanup_log, uinfo, commit_params)

                        cleanup_plan_paths.append(sdp_comp._path)
                        cleanup_plan_paths.append(ietf_nss_plan.status_code_detail._path)
                else:
                    for component in ietf_nss_plan.component:
                        force_back_track_comp.append(
                            (
                                component.force_back_track,
                                service_xp
                            )
                        )

                        if component.type == const.NCS_SELF:
                            continue

                        for ac_id in component.attachment_circuit:
                            nodes.add(
                                (
                                    component.name,
                                    component.node,
                                    ac_id
                                )
                            )

                    CleanupUtils.delete_service(self, service_kp, cleanup_log, uinfo, commit_params)

                    cleanup_entire_service = True
                    cleanup_plan_paths.append(plan_kp)

                self._cleanup_service(
                    th,
                    root,
                    uinfo,
                    service_id,
                    nm_vpn_id,
                    internal_sr_te_odn_name,
                    pm_svc_profile_name,
                    no_networking,
                    service_xp,
                    force_back_track_comp,
                    cleanup_plan_paths,
                    cleanup_log,
                    service_tag_service,
                    nodes,
                    cleanup_entire_service
                )

                TsdnUtils.redeploy_service(service_kp, plan_kp, uinfo.username, self.log)

                self.log.info("Cleanup Successful for IETF NSS")
                cleanup_log.append("\n Cleanup Successful for IETF NSS \n")
                output.success = True

        except Exception as e:
            self.log.exception(f"Exception in IETFNSSCleanupAction() : {e}")
            exp = CustomActionException(self.log, StatusCodes.CLEANUP_ERROR, str(e)) \
                .set_context("Cleanup Action", "Service cleanup failed").finish()
            cleanup_log.append(f'\nERROR: {exp}')
            output.success = False
        finally:
            output.detail = "".join(cleanup_log)
            TsdnUtils.delete_service_cleanup_flag(self, service_kp, uinfo.username)

    def _cleanup_service(self, th, root, uinfo, service_id, nm_vpn_id, internal_sr_te_odn_name,
                         pm_svc_profile_name, no_networking, service_xp,
                         force_back_track_comp, cleanup_plan_paths, cleanup_log,
                         service_tag_service, nodes, cleanup_entire_service):

        self._invoke_internal_pm_cleanup(
            root,
            pm_svc_profile_name,
            no_networking,
            cleanup_log,
            nodes
        )

        self._invoke_internal_odn_cleanup(
            root,
            internal_sr_te_odn_name,
            no_networking,
            cleanup_log,
            nodes
        )

        self._invoke_internal_nm_cleanup(
            root,
            nm_vpn_id,
            no_networking,
            cleanup_log,
            service_tag_service,
            cleanup_entire_service,
            nodes
        )

        # Force-backtrack all upper service components - RT#48440 Filed
        CleanupUtils.invoke_backtrack_actions(self, service_id, force_back_track_comp,
                                              no_networking)
        cleanup_log.append("\n Removed all plan components")

        for cleanup_plan_path in cleanup_plan_paths:
            CleanupUtils.remove_plan_paths(self, cleanup_plan_path, cleanup_log, uinfo)

        if cleanup_entire_service:
            CleanupUtils.remove_zombie(self, service_xp, cleanup_log, uinfo)

        # Due to zombie removal race conditions
        # plan elements are partially recreated causing cleanup leftovers.
        # This does a final check on plan path removal.
        for cleanup_plan_path in cleanup_plan_paths:
            CleanupUtils.remove_plan_paths(self, cleanup_plan_path, cleanup_log, uinfo)

        # Workaround IEFT NSS may not own ODN service, so we need to re-deploy to cleanup
        # leftover zombies. Seems to occur on non-LSA environment
        if internal_sr_te_odn_name is not None:
            for (_, node_id, _) in nodes:
                odn_internal_kp = f"{odn_const.SR_TE_ODN_INTERNAL_SERVICE_PATH}" \
                    f"[name='{internal_sr_te_odn_name}'][head-end='{node_id}']"

                odn_zombie_kp = f'{const.ZOMBIE_PATH}{{"{odn_internal_kp}"}}'

                if th.exists(odn_zombie_kp):
                    get_node(th, odn_zombie_kp).re_deploy()

    def _invoke_internal_pm_cleanup(self, root, internal_svc_profile_name, no_networking,
                                    cleanup_log, nodes):
        if internal_svc_profile_name is None:
            return

        pm_cleanup_action = root.cisco_pm_fp__pm.pm_actions.cleanup

        self.log.info(f"PM cleanup action: {pm_cleanup_action._path}")

        pm_cleanup_input = pm_cleanup_action.get_input()
        pm_cleanup_input.service = internal_svc_profile_name
        pm_cleanup_input.no_networking = no_networking

        pm_plan = utils.get_pm_plan(root, internal_svc_profile_name)

        if pm_plan is None:
            return

        for (_, node_id, _) in nodes:
            pm_comp = (pm_const.PM_DEVICE, node_id)

            if pm_comp not in pm_plan.component:
                continue

            # We don't want to delete device was pre-configured,
            # so only remove if component has back-tracked
            # ( ie. deleted by service assuming it's the owner )
            if not pm_plan.component[pm_comp].back_track:
                continue

            pm_cleanup_input.device = node_id

            pm_cleanup_output = pm_cleanup_action(pm_cleanup_input)
            cleanup_log.append(pm_cleanup_output.detail)

            if not pm_cleanup_output.success:
                raise Exception("Internal ODN Service Cleanup Failed")

    def _invoke_internal_odn_cleanup(self, root, internal_sr_te_odn_name, no_networking,
                                     cleanup_log, nodes):
        if internal_sr_te_odn_name is None:
            return

        odn_cleanup_action = root.cisco_sr_te_cfp__sr_te.cleanup

        self.log.info(f"SR ODN cleanup action: {odn_cleanup_action._path}")

        odn_cleanup_input = odn_cleanup_action.get_input()
        odn_cleanup_input.service_type = "sr-odn"
        odn_cleanup_input.service = internal_sr_te_odn_name
        odn_cleanup_input.no_networking = no_networking

        odn_plan = utils.get_sr_te_odn_plan(root, internal_sr_te_odn_name)

        if odn_plan is None:
            return

        for (_, node_id, _) in nodes:
            odn_comp = (odn_const.SR_TE_ODN_HEAD_END, node_id)

            if odn_comp not in odn_plan.component:
                continue

            # We don't want to delete device was pre-configured,
            # so only remove if component has back-tracked
            # ( ie. deleted by service assuming it's the owner )
            if not odn_plan.component[odn_comp].back_track:
                continue

            odn_cleanup_input.device = node_id

            odn_cleanup_output = odn_cleanup_action(odn_cleanup_input)
            cleanup_log.append(odn_cleanup_output.detail)

            if not odn_cleanup_output.success:
                raise Exception("Internal ODN Service Cleanup Failed")

    def _invoke_internal_nm_cleanup(self, root, nm_vpn_id, no_networking, cleanup_log,
                                    service_tag_service, cleanup_entire_service, nodes):
        if service_tag_service == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L2:
            nm_cleanup_action = root.l2vpn_ntw__l2vpn_ntw.l2nm_actions.cleanup
        else:
            nm_cleanup_action = root.l3nm__l3vpn_ntw.cisco_l3nm__l3nm_actions.cleanup

        self.log.info(f"NM cleanup action: {nm_cleanup_action._path}")

        nm_cleanup_input = nm_cleanup_action.get_input()
        nm_cleanup_input.service = nm_vpn_id
        nm_cleanup_input.no_networking = no_networking

        if cleanup_entire_service:
            nm_cleanup_output = nm_cleanup_action(nm_cleanup_input)
            cleanup_log.append(nm_cleanup_output.detail)

            if not nm_cleanup_output.success:
                raise Exception("Internal NM Service Cleanup Failed")
        else:
            for (sdp_id, node_id, ac_id) in nodes:
                nm_cleanup_input.vpn_node = node_id
                nm_cleanup_input.vpn_network_access_id = \
                    utils.get_internal_nm_vpn_network_access_id(sdp_id, ac_id)

                nm_cleanup_output = nm_cleanup_action(nm_cleanup_input)
                cleanup_log.append(nm_cleanup_output.detail)

                if not nm_cleanup_output.success:
                    raise Exception("Internal NM Service Cleanup Failed")


class IETFNSSErrorRecoveryAction(Action):
    """
    Action handler for IETF NSS services site error recovery
    """
    @Action.action
    def cb_action(self, uinfo, name, kp, input, output):
        _ncs.dp.action_set_timeout(uinfo, TsdnUtils.get_action_timeout(self, uinfo.username))
        self.log.info(f"Running IETF NSS Recovery action : {kp}")

        service_id = input.service
        sync_direction = input.sync_direction

        recovery_log = \
            [f"Recovering IETF NSS service: {service_id} sync_direction: {sync_direction} \n"]

        try:
            with single_read_trans(uinfo.username, "system", db=OPERATIONAL) as th:
                root = get_root(th)
                ietf_nss_plan = utils.get_ietf_nss_plan(root, service_id)

                pm_error_recovery_output = self._trigger_pm_error_recovery_action(
                    root,
                    ietf_nss_plan,
                    sync_direction
                )

                odn_error_recovery_output = self._trigger_internal_odn_error_recovery_action(
                    root,
                    ietf_nss_plan,
                    sync_direction
                )

                if pm_error_recovery_output is not None:
                    output.success = pm_error_recovery_output.success
                    recovery_log.append(pm_error_recovery_output.detail)\

                if odn_error_recovery_output is not None:
                    output.success = odn_error_recovery_output.success
                    recovery_log.append(odn_error_recovery_output.detail)

                nm_error_recovery_output = self._trigger_internal_nm_error_recovery_action(
                    root,
                    ietf_nss_plan,
                    service_id,
                    sync_direction
                )

                if output.success:
                    output.success = nm_error_recovery_output.success

                slice_service = utils.get_ietf_nss_service(root, service_id)
                if slice_service is not None:
                    slice_service.re_deploy()

                recovery_log.append(nm_error_recovery_output.detail)
                output.detail = ''.join(recovery_log)

        except Exception as e:
            self.log.exception(f"Exception IETF NSS RecoveryAction: {e}")
            exp = CustomActionException(self.log, StatusCodes.RECOVERY_ERROR, str(e)) \
                .set_context("Recovery Action", f"Recovery failed for {service_id}")\
                .finish()
            recovery_log.append("\nRecovery Failed\n\n")
            output.success = False
            recovery_log.append(str(exp))
            output.detail = ''.join(recovery_log)

    def _trigger_pm_error_recovery_action(self, root, ietf_nss_plan, sync_direction):
        pm_svc_profile_name = utils.get_pm_svc_profile_name_oper(ietf_nss_plan)

        if pm_svc_profile_name is None:
            return

        pm_error_recovery = root.cisco_pm_fp__pm.pm_actions.error_recovery

        pm_error_recovery_input = pm_error_recovery.get_input()
        pm_error_recovery_input.service = pm_svc_profile_name
        pm_error_recovery_input.sync_direction = sync_direction

        return pm_error_recovery(pm_error_recovery_input)

    def _trigger_internal_odn_error_recovery_action(self, root, ietf_nss_plan, sync_direction):
        internal_sr_te_odn_name = utils.get_internal_sr_te_odn_name_oper(ietf_nss_plan)

        if internal_sr_te_odn_name is None:
            return

        odn_error_recovery = root.cisco_sr_te_cfp__sr_te.error_recovery

        odn_error_recovery_input = odn_error_recovery.get_input()
        odn_error_recovery_input.service_type = "sr-odn"
        odn_error_recovery_input.service = internal_sr_te_odn_name
        odn_error_recovery_input.sync_direction = sync_direction

        return odn_error_recovery(odn_error_recovery_input)

    def _trigger_internal_nm_error_recovery_action(self, root, ietf_nss_plan,
                                                   service_id, sync_direction):
        service_type = utils.get_service_tag_service_oper(ietf_nss_plan)

        if service_type == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L2:
            nm_error_recovery_action = root.l2vpn_ntw__l2vpn_ntw.l2nm_actions.error_recovery
        else:
            nm_error_recovery_action = \
                root.l3nm__l3vpn_ntw.cisco_l3nm__l3nm_actions.error_recovery

        nm_error_recovery_input = nm_error_recovery_action.get_input()
        nm_error_recovery_input.service = utils.get_internal_vpn_id(service_id)
        nm_error_recovery_input.sync_direction = sync_direction

        return nm_error_recovery_action(nm_error_recovery_input)
