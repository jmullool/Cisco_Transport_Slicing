import logging

from abc import abstractmethod
from ncs.application import NanoService
from ncs.template import Template, Variables
from core_fp_common import instrumentation
from cisco_tsdn_core_fp_common import constants as const, ietf_nss_const as nss_const


class Vars(object):
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)


class Component(NanoService):
    """
    Generic component handler
    """
    @NanoService.create
    @instrumentation.instrument_nano(logging.INFO, nss_const.IETF_NSS_SERVICEPOINT)
    def cb_nano_create(self, tctx, root, service, plan,
                       component, state, opaque, comp_vars):
        opaque_dict = dict(opaque)
        if opaque_dict.get("VALIDATION_ERROR") != "":
            return opaque

        vars = self._init_class_vars(
            root,
            service,
            plan,
            component,
            state,
            dict(opaque),
            comp_vars,
            tctx
        )

        try:
            if state == const.NCS_INIT:
                self._create_init(vars)
            elif state == const.NCS_READY:
                self._create_ready(vars)
            elif state == nss_const.IETF_NSS_CONFIG_APPLY:
                self._create_config_apply(vars)
            else:
                raise Exception(f"Internal Error: Unable to find valid state callback, {state},"
                                f" for component, {component}")

            return list(vars.opaque.items())

        except Exception as e:
            self.log.exception(e)
            opaque_dict["VALIDATION_ERROR"] = str(e)
            return list(opaque_dict.items())

    @NanoService.delete
    @instrumentation.instrument_nano(logging.INFO, nss_const.IETF_NSS_SERVICEPOINT)
    def cb_nano_delete(self, tctx, root, service, plan,
                       component, state, opaque, comp_vars):
        vars = self._init_class_vars(
            root,
            service,
            plan,
            component,
            state,
            dict(opaque),
            comp_vars,
            tctx
        )

        if state == const.NCS_INIT:
            self._delete_init(vars)

            return list(vars.opaque.items())
        else:
            raise Exception(f"Internal Error: Unable to find valid state callback, {state},"
                            f" for component, {component}")

    @abstractmethod
    def _create_init():
        pass

    @abstractmethod
    def _create_ready():
        pass

    @abstractmethod
    def _create_config_apply():
        pass

    @abstractmethod
    def _delete_init():
        pass

    def _init_class_vars(self, root, service, plan, component, state, opaque_dict, comp_vars, tctx):
        dict_comp_vars = dict(comp_vars)

        return Vars(
            root=root,
            service=service,
            plan=plan,
            comp_key=component,
            component=plan.component[component],
            state=plan.component[component].state[state],
            state_key=state,
            opaque=opaque_dict,
            template=Template(service),
            variables=Variables(comp_vars),
            tctx=tctx,
            comp_vars=dict_comp_vars,
            service_id=dict_comp_vars["SERVICE_ID"],
            service_tag_service=dict_comp_vars["SERVICE_TAG_SERVICE"]
        )
