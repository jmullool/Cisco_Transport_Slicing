from ietf_network_slice_service.nano_plan.component import Component
from ietf_network_slice_service import utils
from cisco_tsdn_core_fp_common import (
    constants as const,
    ietf_nss_const as nss_const
)


class IETFNSSSharedSliceCallback(Component):
    """
    NanoService callback handler for ietf-network-slice-service self component
    """
    def _create_init(self, vars):
        shared_plan_status = \
            utils.get_ietf_nss_plan_status(vars.root, vars.comp_vars["SHARED_SERVICE_ID"])

        if shared_plan_status is not None:
            shared_plan_status.dedicated_slice.create(vars.service.service_id)
        else:
            vars.state.status = const.STATUS_NOT_REACHED
            return

    def _create_config_apply(self, vars):
        shared_service_id = vars.comp_vars["SHARED_SERVICE_ID"]
        shared_plan_status = utils.get_ietf_nss_plan_status(vars.root, shared_service_id)
        if shared_plan_status.rt_allocation_data.hub_rt is not None:
            spoke_rt = \
                utils.var_or_default(vars.plan.status.rt_allocation_data.spoke_rt)

            if vars.plan.status.color_allocation_data.color is not None:
                slo_sle_template = utils.get_slo_sle_template(vars.root, vars.service)
                internal_sr_te_odn_name = \
                    utils.get_internal_sr_te_odn_name(slo_sle_template, vars.service)
            else:
                internal_sr_te_odn_name = ''

            if not vars.service.shared.single_sided_control:
                shared_service = utils.get_ietf_nss_service(vars.root, shared_service_id)
                shared_slo_sle_template = utils.get_slo_sle_template(vars.root, shared_service)
                shared_internal_sr_te_odn_name = utils.get_internal_sr_te_odn_name(
                    shared_slo_sle_template,
                    shared_service
                )
                shared_internal_sr_te_odn_name = \
                    utils.var_or_default(shared_internal_sr_te_odn_name)
            else:
                shared_internal_sr_te_odn_name = ''

            vars.variables.add("SHARED_INTERNAL_SR_TE_ODN_NAME", shared_internal_sr_te_odn_name)
            vars.variables.add(
                "INTERNAL_VPN_ID", utils.get_internal_vpn_id(vars.service.service_id)
            )
            vars.variables.add("INTERNAL_SR_TE_ODN_NAME", internal_sr_te_odn_name)
            vars.variables.add("HUB_RT", vars.plan.status.rt_allocation_data.hub_rt)
            vars.variables.add("SPOKE_RT", spoke_rt)
            vars.variables.add("SHARED_SERVICE_ID", shared_service_id)
            vars.variables.add("SHARED_HUB_RT", shared_plan_status.rt_allocation_data.hub_rt)

            if vars.service_tag_service == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L2:
                vars.template.apply("ietf-nss-shared-slice-l2nm", vars.variables)
            elif vars.service_tag_service == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L3:
                vars.variables.add("SERVICE_ID", vars.service.service_id)
                vars.template.apply("ietf-nss-shared-slice-l3nm", vars.variables)
            else:
                utils.raise_invalid_service_type("_create_config_apply()", vars.service_tag_service)

            vars.template.apply("ietf-nss-shared-slice", vars.variables)
        else:
            vars.state.status = const.STATUS_NOT_REACHED

    def _create_ready(self, vars):
        shared_service_id = vars.comp_vars["SHARED_SERVICE_ID"]
        shared_plan = utils.get_ietf_nss_plan(vars.root, shared_service_id)
        shared_state = shared_plan.component[const.SELF_COMP_KEY].state[const.NCS_READY]

        vars.state.status = shared_state.status

        if shared_plan.failed.exists():
            vars.state.status = const.STATUS_FAILED
