from ietf_network_slice_service.nano_plan.component import Component
from ietf_network_slice_service import utils
from cisco_tsdn_core_fp_common import (
    constants as const,
    ietf_nss_const as nss_const,
    utils as TsdnUtils
)


class IETFNSSSelfCallback(Component):
    """
    NanoService callback handler for ietf-network-slice-service self component
    """
    def _create_init(self, vars):
        self._update_plan_rt_allocation_data(vars)
        connection_group = utils.get_connection_group(vars.service)
        connectivity_type = connection_group.connectivity_type

        if vars.service_tag_service == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L2:
            self._allocate_and_update_evi_id(vars, connectivity_type)

            if utils.is_y_1731_enabled(vars.root, vars.service):
                self._allocate_and_update_mep_id(vars)
                self._allocate_sman_id(vars)

        slo_sle_template = utils.get_slo_sle_template(vars.root, vars.service)

        (internal_sr_te_odn_name, color, _, color_per_slice) = \
            utils.get_internal_sr_te_odn_details(
                self.log,
                vars.tctx,
                vars.root,
                slo_sle_template,
                vars.service
        )

        if color is not None:
            vars.plan.status.color_allocation_data.color = color

            vars.variables.add("COLOR", color)

            if color_per_slice or slo_sle_template.service_assurance.performance_measurement:
                bandwidth = connection_group.service_slo_sle_policy.bandwidth

                utils.create_dedicated_sr_te_odn(
                    slo_sle_template,
                    internal_sr_te_odn_name,
                    color,
                    bandwidth
                )

            internal_route_policy_name = None

            if connectivity_type == nss_const.IETF_NSS_POINT_TO_POINT:
                evi_id = utils.get_evi_id_oper(vars.plan)

                if evi_id is None:
                    return

                internal_route_policy_name = \
                    utils.get_internal_route_policy_name(slo_sle_template, vars.service_id, evi_id)

                vars.variables.add("EVI_ID", evi_id)
                vars.variables.add(
                    "MANUAL_L2_RP",
                    f"evpn-route-type is 1 and rd in (ios-regex '.*:({evi_id})$')"
                )

                template = "ietf-nss-self-l2vpn-p2p-route-policy"

            elif slo_sle_template.custom:
                internal_route_policy_name = \
                    utils.get_internal_route_policy_name(slo_sle_template, vars.service_id)

                if vars.service_tag_service == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L2:
                    template = "ietf-nss-self-l2vpn-mp-route-policy"
                else:
                    template = "ietf-nss-self-l3vpn-route-policy"

            if internal_route_policy_name is not None:
                vars.variables.add("INTERNAL_ROUTE_POLICY_NAME", internal_route_policy_name)
                vars.template.apply(template, vars.variables)

    def _create_ready(self, vars):
        self._verify_plan(vars)

    def _delete_init(self, vars):
        self._verify_plan(vars)

    def _verify_plan(self, vars):
        nm_plan = utils.get_internal_nm_plan(
            vars.root,
            vars.service_id,
            vars.service_tag_service
        )

        if nm_plan is not None:
            if vars.comp_key in nm_plan.component:
                nm_self_state = nm_plan.component[vars.comp_key].state[vars.state_key]
                vars.state.status = nm_self_state.status

            if nm_plan.failed.exists():
                vars.state.status = const.STATUS_FAILED
                vars.plan.failed.create()

                if nm_plan.error_info:
                    vars.plan.error_info.create()
                    vars.plan.error_info.message = nm_plan.error_info.message
                return

        for component in vars.plan.component:
            if component == vars.comp_key:
                continue

            for state in component.state:
                if state.status == const.STATUS_FAILED:
                    vars.state.status = const.STATUS_FAILED

                    if not vars.plan.failed.exists():
                        vars.plan.failed.create()

                    return
                elif state.status == const.STATUS_NOT_REACHED:
                    vars.state.status = const.STATUS_NOT_REACHED
                    return

    def _update_plan_rt_allocation_data(self, vars):
        connection_group = utils.get_connection_group(vars.service)

        if connection_group.connectivity_type != nss_const.IETF_NSS_POINT_TO_POINT:
            (hub_rt, spoke_rt) = self._get_rt(vars, connection_group)

            vars.plan.status.rt_allocation_data.hub_rt = hub_rt
            if spoke_rt is not None:
                vars.plan.status.rt_allocation_data.spoke_rt = spoke_rt

    def _get_rt(self, vars, connection_group):
        hub_rt = None
        spoke_rt = None

        if connection_group.connectivity_type == const.VPN_COMMON_ANY_TO_ANY:
            hub_rt = self._get_hub_rt(vars, connection_group)
        elif connection_group.connectivity_type == const.VPN_COMMON_HUB_SPOKE:
            hub_rt = self._get_hub_rt(vars, connection_group)
            spoke_rt = self._get_spoke_rt(vars, connection_group)
        else:  # this should never run
            raise Exception("_get_rt(): Invalid topology")

        return (hub_rt, spoke_rt)

    def _get_hub_rt(self, vars, connection_group):
        if connection_group.vpn_target.hub_rt_choice == const.AUTO_HUB_RT:
            return self._allocate_rt(vars, f"{vars.service.service_id}-hub-rt-value")
        else:
            return connection_group.vpn_target.hub_rt

    def _get_spoke_rt(self, vars, connection_group):
        if connection_group.vpn_target.spoke_rt_choice == const.AUTO_SPOKE_RT:
            return self._allocate_rt(vars, f"{vars.service.service_id}-spoke-rt-value")
        else:
            return connection_group.vpn_target.spoke_rt

    def _allocate_rt(self, vars, allocation_name):
        if vars.service_tag_service == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L2:
            pool_name = vars.root.l2vpn_ntw__l2vpn_ntw.id_pools.rt_pool_name
        else:
            pool_name = vars.root.l3nm__l3vpn_ntw.cfp_configurations.resource_pools.rt_pool_name

        rt = utils.request_id_allocation(
            vars.root,
            vars.service,
            utils.get_ietf_nss_service_xp(vars.service.service_id),
            vars.tctx.username,
            pool_name,
            allocation_name,
            self.log,
            vars.state
        )

        return TsdnUtils.get_rt_value_with_prefix(int(rt))

    def _allocate_and_update_evi_id(self, vars, connectivity_type):
        nss_evi_allocation_data = vars.plan.status.evi_allocation_data
        l2nm_pools = vars.root.l2vpn_ntw__l2vpn_ntw.id_pools

        # We only allocate evi-id through NSS, since it's used for L2 P2P
        # l2vpn-route-policy configuration
        nss_evi_allocation_data.evi_id = utils.request_id_allocation(
            vars.root,
            vars.service,
            utils.get_ietf_nss_service_xp(vars.service.service_id),
            vars.tctx.username,
            l2nm_pools.evi_id_pool_name,
            f"{vars.service.service_id}-evi-id",
            self.log
        )

        if connectivity_type == nss_const.IETF_NSS_POINT_TO_POINT:
            nss_evi_allocation_data.evi_source = utils.request_id_allocation(
                vars.root,
                vars.service,
                utils.get_ietf_nss_service_xp(vars.service.service_id),
                vars.tctx.username,
                l2nm_pools.evi_source_target_pool_name,
                f"{vars.service.service_id}-evi-source",
                self.log
            )
            nss_evi_allocation_data.evi_target = utils.request_id_allocation(
                vars.root,
                vars.service,
                utils.get_ietf_nss_service_xp(vars.service.service_id),
                vars.tctx.username,
                l2nm_pools.evi_source_target_pool_name,
                f"{vars.service.service_id}-evi-target",
                self.log
            )

    def _allocate_and_update_mep_id(self, vars):
        for sdp in vars.service.sdps.sdp:
            allocation_name = f"{vars.service.service_id}-{sdp.sdp_id}-mep-id"
            mep_id_pool_name = vars.root.network_slice_services.cfp_configurations.mep_id_pool_name

            mep_id = utils.request_id_allocation(
                vars.root,
                vars.service,
                utils.get_ietf_nss_service_xp(vars.service.service_id),
                vars.tctx.username,
                mep_id_pool_name,
                allocation_name,
                self.log,
                state=vars.state
            )

            mep_id_allocation_data = vars.plan.status.mep_id_allocation_data
            mep_id_alloc_sdp = mep_id_allocation_data.sdp.create(sdp.sdp_id)
            mep_id_alloc_sdp.mep_id = mep_id

    def _allocate_sman_id(self, vars):
        allocation_name = f"{vars.service.service_id}-sman-id"

        sman_id = utils.request_id_allocation(
            vars.root,
            vars.service,
            utils.get_ietf_nss_service_xp(vars.service.service_id),
            vars.tctx.username,
            "sman-id-pool",
            allocation_name,
            self.log,
            state=vars.state
        )

        sman_id_allocation_data = vars.plan.status.sman_id_allocation_data
        sman_id_allocation_data.sman_id = sman_id
