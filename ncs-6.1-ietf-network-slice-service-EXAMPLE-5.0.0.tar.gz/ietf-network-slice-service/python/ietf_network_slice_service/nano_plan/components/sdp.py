import json

from ncs import maagic
from cisco_tsdn_core_fp_common import (
    constants as const,
    ietf_L2vpn_nm_const as l2nm_const,
    ietf_l3vpn_nm_const as l3nm_const,
    sr_te_odn_const as odn_const,
    ietf_nss_const as nss_const,
    utils as TsdnUtils,
    pm_const
)
from ietf_network_slice_service import utils
from ietf_network_slice_service.nano_plan.component import Component


class IETFNSSSDPCallback(Component):
    """
    NanoService callback handler for ietf-network-slice-service self component
    """

    def _create_init(self, vars):

        node_id = vars.comp_vars["NODE_ID"]
        sdp_id = vars.comp_vars["SDP_ID"]

        sdp = vars.service.sdps.sdp[sdp_id]
        comp_opaque_key = f"SDP_{sdp_id}_COMPS"

        vars.opaque[comp_opaque_key] = []

        for ac in sdp.attachment_circuits.attachment_circuit:
            comp_name = \
                utils.get_sdp_internal_nm_comp_name(vars.service, node_id, sdp.sdp_id, ac.ac_id)
            vars.opaque[comp_opaque_key].append(comp_name)

        # Store list as json string to load/retrieve as list later
        vars.opaque[comp_opaque_key] = json.dumps(vars.opaque[comp_opaque_key])

    def _create_config_apply(self, vars):
        slo_sle_template = utils.get_slo_sle_template(vars.root, vars.service)
        connectivity_type = utils.get_connection_group(vars.service).connectivity_type

        if slo_sle_template.service_assurance.performance_measurement:
            vars.variables.add(
                "PM_SVC_PROFILE",
                slo_sle_template.service_assurance.performance_measurement.sr_te.pm_svc_profile
            )
            vars.template.apply("ietf-nss-pm-svc-profile", vars.variables)

        if vars.service_tag_service == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L2:
            parent_rr_route_policy = ''
            locator_name = ''
            internal_route_policy_name = ''
            is_point_to_point = False
            evi_id = utils.get_evi_id_oper(vars.plan)
            evi_source = ''
            evi_target = ''
            sman_id = ''

            if connectivity_type == nss_const.IETF_NSS_POINT_TO_POINT:
                is_point_to_point = True

                evi_source = utils.get_evi_source_oper(vars.plan)
                evi_target = utils.get_evi_target_oper(vars.plan)
                sman_id = utils.get_sman_id_oper(vars.plan)

                parent_rr_route_policy = vars.root.ietf_nss__network_slice_services.\
                    global_settings.parent_rr_route_policy

                sr_te_odn_service = \
                    utils.get_sr_te_odn_service(vars.root, slo_sle_template.forwarding_plane_policy)

                if sr_te_odn_service and sr_te_odn_service.srv6 and sr_te_odn_service.srv6.locator:
                    locator_name = sr_te_odn_service.srv6.locator.locator_name

                locator_name = utils.var_or_default(locator_name)
                internal_route_policy_name = \
                    utils.get_internal_route_policy_name(slo_sle_template, vars.service_id, evi_id)
            else:
                internal_route_policy_name = \
                    utils.get_internal_route_policy_name(slo_sle_template, vars.service_id)

            (input_qos_policy, output_qos_policy) = self._get_l2_qos_policies(slo_sle_template)
            nm_topology = self._get_internal_l2nm_vpn_topology(connectivity_type)
            nm_node_role = self._get_internal_l2nm_node_role(vars)

            vars.variables.add("VPN_TYPE", self._get_internal_l2nm_vpn_type(connectivity_type))
            vars.variables.add("NODE_ROLE", self._get_internal_l2nm_node_role(vars))
            vars.variables.add("PARENT_RR_ROUTE_POLICY", parent_rr_route_policy)
            vars.variables.add("LOCATOR_NAME", locator_name)
            vars.variables.add("MEP_ID", self._get_mep_id(vars))
            vars.variables.add("EVI_ID", evi_id)
            vars.variables.add("EVI_SOURCE", evi_source)
            vars.variables.add("EVI_TARGET", evi_target)
            vars.variables.add("SMAN_ID", sman_id)

            (monitoring_state, preservation, profile_name, rule_name) = \
                self._get_heuristics(slo_sle_template, vars, is_point_to_point)

            template_name = "ietf-nss-sdp-l2nm"

        else:
            internal_route_policy_name = \
                utils.get_internal_route_policy_name(slo_sle_template, vars.service_id)

            (input_qos_policy, output_qos_policy) = self._get_l3_qos_policies(slo_sle_template)
            nm_topology = self._get_internal_l3nm_vpn_topology(connectivity_type)
            nm_node_role = self._get_internal_l3nm_node_role(vars)

            (monitoring_state, preservation, profile_name, rule_name) = \
                self._get_heuristics(slo_sle_template, vars)

            template_name = "ietf-nss-sdp-l3nm"

        if vars.plan.status.color_allocation_data.color is not None:
            internal_sr_te_odn_name = \
                utils.get_internal_sr_te_odn_name(slo_sle_template, vars.service)
        else:
            internal_sr_te_odn_name = ''

        internal_route_policy_name = utils.var_or_default(internal_route_policy_name)

        # Common variables for L2 and L3
        vars.variables.add(
            "INTERNAL_VPN_ID",
            utils.get_internal_vpn_id(vars.service.service_id)
        )
        vars.variables.add("INTERNAL_SR_TE_ODN_NAME", internal_sr_te_odn_name)
        vars.variables.add("TOPOLOGY", nm_topology)
        vars.variables.add("NODE_ROLE", nm_node_role)

        if vars.plan.status.rt_allocation_data:
            rt_allocation_data = vars.plan.status.rt_allocation_data
            vars.variables.add("HUB_RT", rt_allocation_data.hub_rt)
            vars.variables.add("SPOKE_RT", utils.var_or_default(rt_allocation_data.spoke_rt))
        else:
            vars.variables.add("HUB_RT", '')
            vars.variables.add("SPOKE_RT", '')

        vars.variables.add("INTERNAL_ROUTE_POLICY_NAME", internal_route_policy_name)
        vars.variables.add("INPUT_QOS_POLICY", input_qos_policy)
        vars.variables.add("OUTPUT_QOS_POLICY", output_qos_policy)

        # Service Assurance
        vars.variables.add("MONITORING_STATE", monitoring_state)
        vars.variables.add("PRESERVATION", preservation)
        vars.variables.add("PROFILE_NAME", profile_name)
        vars.variables.add("RULE_NAME", rule_name)

        vars.template.apply(template_name, vars.variables)

    def _create_ready(self, vars):
        nm_plan = \
            utils.get_internal_nm_plan(vars.root, vars.service.service_id, vars.service_tag_service)

        if nm_plan is None:
            vars.state.status = const.STATUS_NOT_REACHED
            return

        for nm_vpn_node_comp_name in self._get_associated_sdp_internal_nm_comps(vars):
            nm_vpn_node_comp_key = (
                utils.get_sdp_internal_nm_comp_type(vars.service_tag_service),
                nm_vpn_node_comp_name
            )

            if nm_vpn_node_comp_key in nm_plan.component:
                nm_vpn_node_state = nm_plan.component[nm_vpn_node_comp_key].state[const.NCS_READY]
                nm_vpn_node_status = nm_vpn_node_state.status

                if nm_vpn_node_status != const.STATUS_REACHED:
                    vars.state.status = nm_vpn_node_status

                    if vars.state.status == const.STATUS_FAILED:
                        self._update_status_codes(nm_vpn_node_comp_key, vars)
                    return
            else:
                vars.state.status = const.STATUS_NOT_REACHED
                return

        slo_sle_template = utils.get_slo_sle_template(vars.root, vars.service)
        internal_sr_te_odn_name = utils.get_internal_sr_te_odn_name(slo_sle_template, vars.service)
        internal_sr_te_odn_plan = \
            utils.get_sr_te_odn_plan(vars.root, internal_sr_te_odn_name)

        vars.variables.add("INTERNAL_SR_TE_ODN_NAME", internal_sr_te_odn_name)

        if internal_sr_te_odn_plan is not None:
            head_end_comp_key = (odn_const.SR_TE_ODN_HEAD_END, vars.comp_vars["NODE_ID"])

            # We only want to monitor via kicker for new head-ends only. There not many options
            # to configure SR ODN via slice-service directly, so the configs are pretty static since
            # ODN is created using valid pre-existing ODN service.
            # If the user goes to config the SR ODN service directly in which case
            # it's expected that SR ODN service will show a failure and the end-user will monitor
            # the SR ODN plan
            if head_end_comp_key not in internal_sr_te_odn_plan.component:
                vars.state.status = const.STATUS_NOT_REACHED
                vars.template.apply("ietf-nss-sr-te-odn-monitor-kicker", vars.variables)

                return

            vars.state.status = \
                internal_sr_te_odn_plan.component[head_end_comp_key].state[const.NCS_READY].status

            if vars.state.status != const.STATUS_REACHED:
                vars.template.apply("ietf-nss-sr-te-odn-monitor-kicker", vars.variables)

                if vars.state.status == const.STATUS_FAILED:
                    TsdnUtils.update_component_status_codes(
                        self,
                        vars.root,
                        maagic.get_node(vars.root, odn_const.SR_TE_ODN_PLAN_PATH),
                        internal_sr_te_odn_name,
                        vars.plan.component[vars.comp_key],
                        head_end_comp_key
                    )
            return

        performance_measurement = slo_sle_template.service_assurance.performance_measurement
        if performance_measurement and performance_measurement.sr_te.pm_svc_profile is not None:
            self.verify_pm_plan(performance_measurement.sr_te.pm_svc_profile, vars)

    def _delete_init(self, vars):
        nm_plan = utils.get_internal_nm_plan(vars.root, vars.service_id, vars.service_tag_service)

        if nm_plan is None:
            self.log.info(f"No NM internal plan for: {vars.service_id}")
            TsdnUtils.remove_status_code_detail(vars.plan, vars.comp_key)
            return

        sdp_comp_name = str(vars.comp_key[1])

        for nm_vpn_node_comp_name in self._get_associated_sdp_internal_nm_comps(vars):
            nm_vpn_node_comp_key = (
                utils.get_sdp_internal_nm_comp_type(vars.service_tag_service),
                nm_vpn_node_comp_name
            )

            if nm_vpn_node_comp_key in nm_plan.component:
                self.log.debug(
                    f"NM vpn-node {nm_vpn_node_comp_key} component "
                    f"found for IETF-NSS sdp {sdp_comp_name}"
                )

                nm_comp_status = \
                    nm_plan.component[nm_vpn_node_comp_key].state[const.NCS_INIT].status

                if nm_comp_status == const.STATUS_FAILED:
                    vars.state.status = const.STATUS_FAILED
                    self._update_status_codes(nm_vpn_node_comp_key, vars)
                    return
                elif nm_comp_status == const.STATUS_REACHED:
                    vars.state.status = const.STATUS_REACHED

    def _get_associated_sdp_internal_nm_comps(self, vars):
        comp_opaque_key = f"SDP_{vars.comp_vars['SDP_ID']}_COMPS"
        associated_nm_comps = json.loads(vars.opaque[comp_opaque_key])

        return associated_nm_comps

    def _get_internal_l2nm_vpn_type(self, connectivity_type):
        if connectivity_type == nss_const.IETF_NSS_POINT_TO_POINT:
            return const.VPN_COMMON_VPWS_EVPN
        elif connectivity_type == const.VPN_COMMON_HUB_SPOKE \
                or connectivity_type == const.VPN_COMMON_ANY_TO_ANY:
            return const.VPN_COMMON_MPLS_EVPN
        else:
            utils.raise_invalid_connectivity_type(
                "_get_internal_l2nm_vpn_type()",
                connectivity_type
            )

    def _get_internal_l2nm_vpn_topology(self, connectivity_type):
        # IETF NSS and L2 both use vpn-common:vpn-topology, except for "ietf-nss:point-to-point"
        return connectivity_type

    def _get_internal_l3nm_vpn_topology(self, connectivity_type):
        if connectivity_type == const.VPN_COMMON_ANY_TO_ANY:
            return l3nm_const.L3NM_ANY_TO_ANY
        elif connectivity_type == const.VPN_COMMON_HUB_SPOKE:
            return l3nm_const.L3NM_HUB_SPOKE
        else:
            utils.raise_invalid_connectivity_type(
                "_get_internal_l3nm_vpn_topology()",
                connectivity_type
            )

    def _get_internal_l2nm_node_role(self, vars):
        sdp_role = utils.get_sdp_role(vars.service.sdps.sdp[vars.comp_vars["SDP_ID"]])

        if sdp_role is None:
            return ''

        return sdp_role

    def _get_internal_l3nm_node_role(self, vars):
        sdp_role = utils.get_sdp_role(vars.service.sdps.sdp[vars.comp_vars["SDP_ID"]])

        if sdp_role is None:
            return ''

        # IETF NSS and L2NM both use 'vpn-common:role'
        if sdp_role == const.VPN_COMMON_SPOKE_ROLE:
            return l3nm_const.L3NM_SPOKE_ROLE
        elif sdp_role == const.VPN_COMMON_HUB_ROLE:  # assume hub even if sdp_role is None
            return l3nm_const.L3NM_HUB_ROLE
        else:
            utils.raise_invalid_input(
                "_get_internal_node_role()",
                "Unsupported SDP Role",
                sdp_role
            )

    def _get_qos_policy(self, qos):
        input_qos_policy = ''
        output_qos_policy = ''

        if qos.input_policy is not None:
            input_qos_policy = qos.input_policy

        if qos.output_policy is not None:
            output_qos_policy = qos.output_policy

        return (input_qos_policy, output_qos_policy)

    def _get_l2_qos_policies(self, slo_sle_template):
        if slo_sle_template.qos_policy.L2.exists():
            return self._get_qos_policy(slo_sle_template.qos_policy.L2)
        else:
            return ('', '')

    def _get_l3_qos_policies(self, slo_sle_template):
        if slo_sle_template.qos_policy.L3.exists():
            return self._get_qos_policy(slo_sle_template.qos_policy.L3)
        else:
            return ('', '')

    def _update_status_codes(self, nm_comp_key, vars):
        nm_service_name = utils.get_internal_vpn_id(vars.service.service_id)

        if vars.service_tag_service == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L2:
            nm_plan_path = maagic.get_node(vars.root, l2nm_const.L2NM_PLAN_PATH)
        elif vars.service_tag_service == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L3:
            nm_plan_path = maagic.get_node(vars.root, l3nm_const.L3NM_PLAN_PATH)
        else:
            utils.raise_invalid_service_type("_update_status_codes()", vars.service_tag_service)

        TsdnUtils.update_plan_status_codes(
            self,
            vars.root,
            vars.plan,
            nm_plan_path,
            nm_service_name
        )
        TsdnUtils.update_component_status_codes(
            self,
            vars.root,
            nm_plan_path,
            nm_service_name,
            vars.plan.component[vars.comp_key],
            nm_comp_key
        )

    def _get_heuristics(self, slo_sle_template, vars, is_point_to_point=False):
        monitoring_state = ''
        preservation = ''
        profile_name = ''
        rule_name = ''

        if slo_sle_template.service_assurance.heuristics:
            heuristics = slo_sle_template.service_assurance.heuristics

            if vars.service_tag_service == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L2 \
                    and heuristics.L2:
                monitoring_state = self._get_heuristics_monitoring_state(heuristics, vars)

                preservation = heuristics.preservation

                if is_point_to_point and heuristics.L2.point_to_point:
                    profile_name = heuristics.L2.point_to_point.profile_name
                    rule_name = heuristics.L2.point_to_point.rule_name
                elif heuristics.L2.multipoint:
                    profile_name = heuristics.L2.multipoint.profile_name
                    rule_name = heuristics.L2.multipoint.rule_name

            elif vars.service_tag_service == nss_const.IETF_NSS_SERVICE_TAG_VALUE_L3 \
                    and heuristics.L3:
                monitoring_state = self._get_heuristics_monitoring_state(heuristics, vars)

                preservation = heuristics.preservation
                profile_name = heuristics.L3.profile_name
                rule_name = heuristics.L3.rule_name

        return (monitoring_state, preservation, profile_name, rule_name)

    def _get_heuristics_monitoring_state(self, heuristics, vars):
        # Override catalog level heuristics with service level if enabled
        if vars.service.service_assurance.heuristics:
            return vars.service.service_assurance.heuristics.monitoring_state
        else:
            return heuristics.monitoring_state

    def _get_mep_id(self, vars):
        mep_id_allocation_data = vars.plan.status.mep_id_allocation_data
        sdp_id = vars.comp_vars["SDP_ID"]

        if sdp_id in mep_id_allocation_data.sdp:
            return mep_id_allocation_data.sdp[sdp_id].mep_id

        return ''

    def verify_pm_plan(self, svc_profile_name, vars):
        pm_plan = utils.get_pm_plan(
            vars.root,
            svc_profile_name
        )

        device_comp_key = (pm_const.PM_DEVICE, vars.comp_vars["NODE_ID"])
        vars.variables.add("SVC_PROFILE_NAME", svc_profile_name)

        if pm_plan is None or device_comp_key not in pm_plan.component:
            vars.state.status = const.STATUS_NOT_REACHED
            vars.template.apply("ietf-nss-pm-plan-monitor-kicker", vars.variables)
        else:
            vars.state.status = pm_plan.component[device_comp_key].state[const.NCS_READY].status

            if vars.state.status != const.STATUS_REACHED:
                vars.template.apply("ietf-nss-pm-plan-monitor-kicker", vars.variables)

                if vars.state.status == const.STATUS_FAILED:
                    TsdnUtils.update_component_status_codes(
                        self,
                        vars.root,
                        maagic.get_node(vars.root, pm_const.PM_PLAN_PATH),
                        svc_profile_name,
                        vars.plan.component[vars.comp_key],
                        device_comp_key
                    )
