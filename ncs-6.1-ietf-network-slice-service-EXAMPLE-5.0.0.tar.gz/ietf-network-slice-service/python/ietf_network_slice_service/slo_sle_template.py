import logging

from ncs.application import Service
from ncs.template import Template, Variables
from core_fp_common import instrumentation
from cisco_tsdn_core_fp_common import ietf_nss_const as nss_const
from ietf_network_slice_service import utils
from _ncs.dp import NCS_SERVICE_CREATE, NCS_SERVICE_UPDATE
from cisco_tsdn_core_fp_common.status_codes.ietf_nss_status_codes import StatusCodes
from cisco_tsdn_core_fp_common.status_codes.ietf_nss_base_exception import UserErrorException


class SloSleTemplateService(Service):
    @Service.pre_modification
    @instrumentation.instrument_service(logging.INFO, nss_const.IETF_NSS_SERVICEPOINT)
    def cb_pre_modification(self, tctx, op, kp, root, proplist):
        status_code_cfp = root.cfp_common_status_codes__status_codes.core_function_pack

        if op == NCS_SERVICE_CREATE and not status_code_cfp.exists("IETF-NSS"):
            raise UserErrorException(
                self.log, StatusCodes.STATUS_CODE_NOT_LOADED
            ).set_context(
                "Status Code", "Missing IETF NSS status code mapping"
            ).add_state(
                "Keypath", str(kp)
            ).finish()
        # Updating certain parameters in slo-sle-template breaks things when
        # active slices are deployed as it can remove SR ODN while slices are
        # actively using SR ODN
        elif op == NCS_SERVICE_UPDATE:
            raise UserErrorException(
                self.log, StatusCodes.VALUE_UPDATE_NOT_SUPPORTED
            ).set_context(
                "Invalid update", "'slo-sle-template' cannot be updated"
            ).add_state(
                "Keypath", str(kp)
            ).finish()

    @Service.create
    @instrumentation.instrument_service(logging.INFO, nss_const.IETF_NSS_SST_SERVICEPOINT)
    def cb_create(self, tctx, root, slo_sle_template, proplist):
        proplist = dict(proplist)

        template = Template(slo_sle_template)
        variables = Variables()

        (internal_sr_te_odn_name, color, color_per_slo_sle_template, _) = \
            utils.get_internal_sr_te_odn_details(
                self.log,
                tctx,
                root,
                slo_sle_template
        )

        if color is not None:
            slo_sle_template.status.color_allocation_data.color = color

            if color_per_slo_sle_template and \
                    not slo_sle_template.service_assurance.performance_measurement:
                utils.create_dedicated_sr_te_odn(slo_sle_template, internal_sr_te_odn_name, color)
        else:
            color = ''

        internal_route_policy_name = utils.get_internal_route_policy_name(slo_sle_template)

        variables.add("COLOR", color)
        variables.add(
            "INTERNAL_ROUTE_POLICY_NAME", utils.var_or_default(internal_route_policy_name)
        )

        template.apply("ietf-nss-slo-sle-template-qos-and-route-policies", variables)
